# JIRA Change Logger Web App V3.2

## New in V3.2
- everything from V3.1
- JIRA CSV import with drag-and-drop upload
- smart column mapping for JIRA Key, Summary, and Description
- preview step before import
- editable preview rows so missing fields can be completed before import
- duplicate handling: skip, overwrite, or merge
- bulk apply system, region, environment, and status during import
- import history panel

## Run
```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Open:
```text
http://127.0.0.1:5000
```

## Default login
- Username: `admin`
- Password: `admin123`

## Region format in settings
```text
Display Name | ISO3 code | aliases separated by commas
United Kingdom | GBR | UK, GB, Great Britain, United Kingdom
Spain | ESP | Spain, ES
Portugal | PRT | Portugal, PT
```

## Notes
- App data is stored in `jira_change_logger.db`
- Attachments are stored in `uploads`
- Import previews are stored temporarily in `import_previews`
- Exports are created in `exports`


## V3.3 additions
- Plugin-based JIRA Sync page with settings toggle
- Daily scheduled sync support
- Releases page and release grouping
- Timeline card on View Change
- In-app notifications dropdown
