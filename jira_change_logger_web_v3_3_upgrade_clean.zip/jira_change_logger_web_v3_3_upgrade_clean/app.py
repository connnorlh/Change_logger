from __future__ import annotations

import csv
import io
import json
import os
import sqlite3
from datetime import datetime, timedelta
from functools import wraps
from pathlib import Path
from typing import Any
from uuid import uuid4

import requests

from flask import (
    Flask,
    abort,
    flash,
    g,
    jsonify,
    make_response,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash
from werkzeug.utils import secure_filename

from query_services import (
    TIME_GROUPING_OPTIONS,
    build_change_where,
    bucket_time_series,
    parse_natural_language_query,
    resolve_chart_grouping,
)

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "jira_change_logger.db"
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)
PREVIEW_DIR = BASE_DIR / "import_previews"
PREVIEW_DIR.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {"txt","pdf","png","jpg","jpeg","gif","doc","docx","xlsx","csv","zip","msg"}
ENV_COLUMNS = {
    "DEV": "dev_date",
    "SIT": "sit_date",
    "UAT": "uat_date",
    "PREPROD": "preprod_date",
    "MIG": "mig_date",
    "PROD": "prod_date",
}
USER_ROLES = ["viewer", "user", "admin"]
PAGE_SIZE_OPTIONS = [25, 50, 100]
DEFAULT_ADMIN_USERNAME = "admin"
DEFAULT_ADMIN_PASSWORD = "admin123"
DEFAULT_SECRET_KEY = "jira-change-logger-local-v34"

DEFAULT_OPTIONS = {
    "themes": ["flatly","cosmo","litera","pulse","morph","zephyr","lux","darkly","cyborg","superhero"],
    "current_theme": "morph",
    "environments": ["DEV", "SIT", "UAT", "PREPROD", "MIG", "PROD"],
    "systems": ["FIS", "D365", "Integration"],
    "change_types": ["Configuration", "Code", "Interface", "Data Fix", "Refresh Redeploy", "Patch"],
    "statuses": ["Planned", "In Progress", "Ready for PROD", "Deployed", "Failed", "Rolled Back"],
    "regions": [
        {"name": "United Kingdom", "iso3": "GBR", "aliases": ["UK", "GB", "Great Britain", "United Kingdom"]},
        {"name": "Spain", "iso3": "ESP", "aliases": ["Spain", "ES"]},
        {"name": "Portugal", "iso3": "PRT", "aliases": ["Portugal", "PT"]},
        {"name": "Italy", "iso3": "ITA", "aliases": ["Italy", "IT"]},
        {"name": "Mexico", "iso3": "MEX", "aliases": ["Mexico", "MX"]},
        {"name": "Peru", "iso3": "PER", "aliases": ["Peru", "PE"]},
        {"name": "Colombia", "iso3": "COL", "aliases": ["Colombia", "Columbia", "CO"]},
    ],
}
DEFAULT_PLUGINS = {
    "jira_sync": False,
    "notifications": True,
    "timeline": True,
    "releases": True,
}
DEFAULT_JIRA_CONFIG = {
    "enabled": False,
    "base_url": "",
    "email": "",
    "api_token": "",
    "project_key": "",
    "jql": "",
    "max_results": 100,
    "schedule_enabled": False,
    "schedule_time": "09:00",
    "sync_strategy": "merge",
}
ANALYTICS_TIME_RANGES = {
    "today": {"label": "Today", "days": 1},
    "7d": {"label": "Last 7 days", "days": 7},
    "30d": {"label": "Last 30 days", "days": 30},
    "90d": {"label": "Last 90 days", "days": 90},
    "custom": {"label": "Custom range", "days": None},
}
IMPORT_FIELD_ALIASES = {
    "jira_ref": ["jira_ref", "jira", "jira key", "issue key", "issuekey", "key", "reference", "ticket"],
    "title": ["title", "summary", "issue summary", "name", "subject"],
    "description": ["description", "issue description", "details", "issue details"],
}

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("JCL_SECRET_KEY") or DEFAULT_SECRET_KEY
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("JCL_SECURE_COOKIE") == "1"


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        conn = sqlite3.connect(DB_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        g.db = conn
    return g.db


@app.teardown_appcontext
def close_db(exception: Exception | None) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


def now_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def today_iso() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def coerce_int(value: Any, fallback: int, minimum: int | None = None, maximum: int | None = None) -> int:
    try:
        result = int(value)
    except (TypeError, ValueError):
        result = fallback
    if minimum is not None:
        result = max(minimum, result)
    if maximum is not None:
        result = min(maximum, result)
    return result


def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def parse_multiline_list(value: str) -> list[str]:
    return [line.strip() for line in value.splitlines() if line.strip()]


def parse_regions(value: str) -> list[dict[str, Any]]:
    regions = []
    for line in value.splitlines():
        line = line.strip()
        if not line:
            continue
        parts = [part.strip() for part in line.split("|")]
        if len(parts) < 2:
            continue
        name = parts[0]
        iso3 = parts[1].upper()
        aliases = []
        if len(parts) >= 3:
            aliases = [a.strip() for a in parts[2].split(",") if a.strip()]
        if name and iso3:
            all_aliases = []
            for item in [name, iso3, *aliases]:
                if item and item not in all_aliases:
                    all_aliases.append(item)
            regions.append({"name": name, "iso3": iso3, "aliases": all_aliases})
    return regions


def serialize_regions_for_textarea(regions: list[dict[str, Any]]) -> str:
    lines = []
    for r in regions:
        aliases = ", ".join(r.get("aliases", []))
        lines.append(f"{r.get('name','')} | {r.get('iso3','')} | {aliases}")
    return "\n".join(lines)


def status_tone(status: str | None) -> str:
    value = (status or "").strip().lower()
    if value in {"deployed", "healthy", "complete"}:
        return "success"
    if value in {"failed", "rolled back", "blocked"}:
        return "danger"
    if value in {"ready for prod", "in progress", "planned", "warning", "stale"}:
        return "warning"
    return "info"


def badge_soft_class(tone: str) -> str:
    return f"badge rounded-pill badge-soft badge-soft-{tone}"


def status_badge_class(status: str | None) -> str:
    return badge_soft_class(status_tone(status))


def risk_badge_class(level: str | None) -> str:
    mapping = {
        "healthy": "success",
        "success": "success",
        "warning": "warning",
        "watch": "warning",
        "danger": "danger",
        "blocked": "danger",
        "neutral": "secondary",
        "info": "info",
    }
    return badge_soft_class(mapping.get((level or "").lower(), "secondary"))


def init_db() -> None:
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    cur = db.cursor()

    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS changes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            jira_ref TEXT NOT NULL,
            title TEXT,
            selected_environment TEXT,
            system_name TEXT,
            change_type TEXT,
            status TEXT,
            version TEXT,
            region TEXT,
            region_iso3 TEXT,
            deployed_by TEXT,
            description TEXT,
            old_value TEXT,
            new_value TEXT,
            dev_date TEXT,
            sit_date TEXT,
            uat_date TEXT,
            preprod_date TEXT,
            mig_date TEXT,
            prod_date TEXT,
            created_by TEXT,
            updated_by TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            change_id INTEGER NOT NULL,
            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            uploaded_at TEXT NOT NULL,
            FOREIGN KEY(change_id) REFERENCES changes(id) ON DELETE CASCADE
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS app_settings (
            setting_key TEXT PRIMARY KEY,
            setting_value TEXT NOT NULL
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'user',
            is_active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id INTEGER,
            details TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS releases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE,
            description TEXT,
            release_date TEXT,
            created_by TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS sync_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            sync_type TEXT NOT NULL,
            status TEXT NOT NULL,
            imported_count INTEGER NOT NULL DEFAULT 0,
            updated_count INTEGER NOT NULL DEFAULT 0,
            merge_count INTEGER NOT NULL DEFAULT 0,
            skipped_count INTEGER NOT NULL DEFAULT 0,
            message TEXT,
            created_at TEXT NOT NULL
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS import_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            file_name TEXT NOT NULL,
            total_rows INTEGER NOT NULL DEFAULT 0,
            imported_count INTEGER NOT NULL DEFAULT 0,
            skipped_count INTEGER NOT NULL DEFAULT 0,
            updated_count INTEGER NOT NULL DEFAULT 0,
            merge_count INTEGER NOT NULL DEFAULT 0,
            strategy TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    db.commit()

    existing_cols = {row["name"] for row in db.execute("PRAGMA table_info(changes)").fetchall()}
    for col, sql_type in {
        "title": "TEXT",
        "region_iso3": "TEXT",
        "created_by": "TEXT",
        "updated_by": "TEXT",
        "release_id": "INTEGER",
    }.items():
        if col not in existing_cols:
            db.execute(f"ALTER TABLE changes ADD COLUMN {col} {sql_type}")
    db.commit()

    for key, value in DEFAULT_OPTIONS.items():
        cur.execute(
            "INSERT OR IGNORE INTO app_settings(setting_key, setting_value) VALUES (?, ?)",
            (key, json.dumps(value)),
        )
    cur.execute(
        "INSERT OR IGNORE INTO app_settings(setting_key, setting_value) VALUES (?, ?)",
        ("jira_import_mapping", json.dumps({"jira_ref": "", "title": "", "description": ""})),
    )
    cur.execute(
        "INSERT OR IGNORE INTO app_settings(setting_key, setting_value) VALUES (?, ?)",
        ("plugins", json.dumps(DEFAULT_PLUGINS)),
    )
    cur.execute(
        "INSERT OR IGNORE INTO app_settings(setting_key, setting_value) VALUES (?, ?)",
        ("jira_api", json.dumps(DEFAULT_JIRA_CONFIG)),
    )
    cur.execute(
        "INSERT OR IGNORE INTO app_settings(setting_key, setting_value) VALUES (?, ?)",
        ("jira_last_auto_sync_date", json.dumps("")),
    )
    db.commit()

    for stmt in [
        "CREATE INDEX IF NOT EXISTS idx_changes_region_iso3 ON changes(region_iso3)",
        "CREATE INDEX IF NOT EXISTS idx_changes_status ON changes(status)",
        "CREATE INDEX IF NOT EXISTS idx_changes_selected_env ON changes(selected_environment)",
        "CREATE INDEX IF NOT EXISTS idx_changes_updated_at ON changes(updated_at)",
    ]:
        cur.execute(stmt)
    db.commit()

    row = cur.execute("SELECT setting_value FROM app_settings WHERE setting_key='regions'").fetchone()
    if row:
        try:
            regions = json.loads(row["setting_value"])
        except Exception:
            regions = []
        if regions and isinstance(regions[0], dict) and "lat" in regions[0]:
            converted = []
            for item in regions:
                name = item.get("name", "")
                alias_list = [name] if name else []
                iso3 = name[:3].upper() if name else ""
                if name.upper() == "UK":
                    iso3 = "GBR"
                    alias_list += ["United Kingdom", "GB", "Great Britain"]
                converted.append({"name": name if name != "UK" else "United Kingdom", "iso3": iso3, "aliases": alias_list})
            cur.execute("UPDATE app_settings SET setting_value=? WHERE setting_key='regions'", (json.dumps(converted),))
            db.commit()

    admin = cur.execute("SELECT 1 FROM users WHERE username=?", (DEFAULT_ADMIN_USERNAME,)).fetchone()
    if not admin:
        cur.execute(
            "INSERT INTO users(username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
            (DEFAULT_ADMIN_USERNAME, generate_password_hash(DEFAULT_ADMIN_PASSWORD), "admin", now_iso()),
        )
    db.commit()
    db.close()


def fetch_setting(key: str, fallback: Any = None) -> Any:
    db = get_db()
    row = db.execute("SELECT setting_value FROM app_settings WHERE setting_key=?", (key,)).fetchone()
    if not row:
        return fallback
    try:
        return json.loads(row["setting_value"])
    except Exception:
        return fallback


def save_setting(key: str, value: Any) -> None:
    db = get_db()
    db.execute(
        """
        INSERT INTO app_settings(setting_key, setting_value)
        VALUES (?, ?)
        ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value
        """,
        (key, json.dumps(value)),
    )
    db.commit()


def get_context_settings() -> dict[str, Any]:
    return {
        "theme": fetch_setting("current_theme", DEFAULT_OPTIONS["current_theme"]),
        "themes": fetch_setting("themes", DEFAULT_OPTIONS["themes"]),
        "environments": fetch_setting("environments", DEFAULT_OPTIONS["environments"]),
        "systems": fetch_setting("systems", DEFAULT_OPTIONS["systems"]),
        "change_types": fetch_setting("change_types", DEFAULT_OPTIONS["change_types"]),
        "statuses": fetch_setting("statuses", DEFAULT_OPTIONS["statuses"]),
        "regions": fetch_setting("regions", DEFAULT_OPTIONS["regions"]),
    }


def get_plugins() -> dict[str, bool]:
    plugins = fetch_setting("plugins", DEFAULT_PLUGINS) or {}
    return {key: bool(plugins.get(key, default)) for key, default in DEFAULT_PLUGINS.items()}


def plugin_enabled(name: str) -> bool:
    return bool(get_plugins().get(name, False))


def get_jira_config() -> dict[str, Any]:
    cfg = fetch_setting("jira_api", DEFAULT_JIRA_CONFIG) or {}
    merged = dict(DEFAULT_JIRA_CONFIG)
    merged.update(cfg)
    return merged


def default_admin_password_active() -> bool:
    db = get_db()
    row = db.execute(
        "SELECT password_hash, is_active FROM users WHERE username=?",
        (DEFAULT_ADMIN_USERNAME,),
    ).fetchone()
    return bool(
        row
        and row["is_active"]
        and check_password_hash(row["password_hash"], DEFAULT_ADMIN_PASSWORD)
    )


def security_summary() -> dict[str, Any]:
    return {
        "default_admin_password_active": default_admin_password_active(),
        "secret_key_configured": bool(os.environ.get("JCL_SECRET_KEY")),
    }


def atlassian_doc_to_text(node: Any) -> str:
    if isinstance(node, str):
        return node
    if isinstance(node, list):
        return "".join(atlassian_doc_to_text(item) for item in node)
    if isinstance(node, dict):
        if node.get("type") == "text":
            return node.get("text", "")
        return "".join(atlassian_doc_to_text(item) for item in node.get("content", []))
    return ""


def get_release_options():
    db = get_db()
    return db.execute(
        """
        SELECT id, name, description, release_date, created_at
        FROM releases
        ORDER BY COALESCE(release_date, created_at) DESC, name
        """
    ).fetchall()


def fetch_notifications(limit: int = 6) -> list[dict[str, Any]]:
    if not plugin_enabled("notifications"):
        return []
    db = get_db()
    notifications = []
    missing = db.execute("SELECT id, jira_ref FROM changes WHERE (prod_date IS NULL OR prod_date='') AND (dev_date IS NOT NULL OR sit_date IS NOT NULL OR uat_date IS NOT NULL OR preprod_date IS NOT NULL OR mig_date IS NOT NULL) ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
    for row in missing[: max(1, limit // 2)]:
        notifications.append({"level": "warning", "message": f"{row['jira_ref']} is not yet in PROD.", "url": url_for("view_change", change_id=row["id"])})
    failed = db.execute("SELECT id, jira_ref FROM changes WHERE status='Failed' ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
    for row in failed[: max(1, limit // 2)]:
        notifications.append({"level": "danger", "message": f"{row['jira_ref']} is marked Failed.", "url": url_for("view_change", change_id=row["id"])})
    return notifications[:limit]


def log_sync_event(username: str | None, sync_type: str, status: str, imported: int, updated: int, merged: int, skipped: int, message: str) -> None:
    db = get_db()
    db.execute("INSERT INTO sync_history(username, sync_type, status, imported_count, updated_count, merge_count, skipped_count, message, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", (username, sync_type, status, imported, updated, merged, skipped, message[:2000], now_iso()))
    db.commit()


def perform_jira_sync(triggered_by: str | None, sync_type: str = "manual") -> dict[str, Any]:
    cfg = get_jira_config()
    if not plugin_enabled("jira_sync") or not cfg.get("enabled"):
        raise ValueError("JIRA Sync plugin is disabled.")
    if not all([cfg.get("base_url"), cfg.get("email"), cfg.get("api_token")]):
        raise ValueError("JIRA API settings are incomplete.")
    jql = cfg.get("jql") or (f"project = {cfg.get('project_key')} ORDER BY updated DESC" if cfg.get("project_key") else "ORDER BY updated DESC")
    response = requests.post(
        cfg["base_url"].rstrip("/") + "/rest/api/3/search",
        auth=(cfg["email"], cfg["api_token"]),
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        json={"jql": jql, "maxResults": int(cfg.get("max_results") or 100), "fields": ["summary", "description"]},
        timeout=30,
    )
    response.raise_for_status()
    issues = response.json().get("issues", [])
    db = get_db()
    imported = updated = merged = skipped = 0
    first_change_id = None
    strategy = cfg.get("sync_strategy", "merge")
    for issue in issues:
        jira_ref = (issue.get("key") or "").strip()
        if not jira_ref:
            skipped += 1
            continue
        fields = issue.get("fields") or {}
        ts = now_iso()
        payload = {
            "jira_ref": jira_ref,
            "title": (fields.get("summary") or "").strip(),
            "selected_environment": "",
            "system_name": "",
            "change_type": "",
            "status": "",
            "version": "",
            "region": "",
            "region_iso3": "",
            "deployed_by": "",
            "description": atlassian_doc_to_text(fields.get("description")).strip()[:20000],
            "old_value": "",
            "new_value": "",
            "dev_date": "",
            "sit_date": "",
            "uat_date": "",
            "preprod_date": "",
            "mig_date": "",
            "prod_date": "",
            "release_id": None,
            "created_by": triggered_by or "system",
            "updated_by": triggered_by or "system",
            "created_at": ts,
            "updated_at": ts,
        }
        existing = db.execute("SELECT * FROM changes WHERE jira_ref=?", (jira_ref,)).fetchone()
        if existing:
            if strategy == "skip":
                skipped += 1
                continue
            if strategy == "overwrite":
                payload["created_by"] = existing["created_by"] or triggered_by or "system"
                payload["created_at"] = existing["created_at"] or ts
                payload["release_id"] = existing["release_id"] if "release_id" in existing.keys() else None
                update_change_record(existing["id"], payload)
                updated += 1
                continue
            merged_row = dict(existing)
            for field in ["title", "description"]:
                if payload[field] and not str(existing[field] or "").strip():
                    merged_row[field] = payload[field]
            merged_row["updated_by"] = triggered_by or "system"
            merged_row["updated_at"] = ts
            update_change_record(existing["id"], merged_row)
            merged += 1
            continue
        change_id = create_change_record(payload)
        imported += 1
        first_change_id = first_change_id or change_id
    msg = f"Processed {len(issues)} issues."
    log_sync_event(triggered_by, sync_type, "success", imported, updated, merged, skipped, msg)
    save_setting("jira_last_auto_sync_date", datetime.now().strftime("%Y-%m-%d"))
    return {"processed": len(issues), "imported": imported, "updated": updated, "merged": merged, "skipped": skipped, "first_change_id": first_change_id, "message": msg}


def maybe_run_scheduled_sync() -> None:
    if not plugin_enabled("jira_sync"):
        return
    cfg = get_jira_config()
    if not (cfg.get("enabled") and cfg.get("schedule_enabled")):
        return
    last_date = fetch_setting("jira_last_auto_sync_date", "") or ""
    now = datetime.now()
    if last_date == now.strftime("%Y-%m-%d"):
        return
    try:
        hour, minute = [int(x) for x in str(cfg.get("schedule_time") or "09:00").split(":", 1)]
    except Exception:
        hour, minute = 9, 0
    if (now.hour, now.minute) < (hour, minute):
        return
    try:
        perform_jira_sync("system", "scheduled")
    except Exception as exc:
        log_sync_event("system", "scheduled", "failed", 0, 0, 0, 0, str(exc))


def log_audit(action: str, entity_type: str, entity_id: int | None = None, details: str = "") -> None:
    db = get_db()
    db.execute(
        "INSERT INTO audit_log(username, action, entity_type, entity_id, details, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (session.get("username"), action, entity_type, entity_id, details[:2000], now_iso()),
    )
    db.commit()


def current_user() -> dict[str, Any] | None:
    if not session.get("user_id"):
        return None
    return {"id": session.get("user_id"), "username": session.get("username"), "role": session.get("role")}


def role_rank(role: str | None) -> int:
    return {"viewer": 1, "user": 2, "admin": 3}.get((role or "").lower(), 0)


def can_edit() -> bool:
    return role_rank(session.get("role")) >= 2


def active_admin_count() -> int:
    db = get_db()
    return db.execute(
        "SELECT COUNT(*) AS c FROM users WHERE role='admin' AND is_active=1"
    ).fetchone()["c"]


def pagination_from_request(args: Any, default_page_size: int = 25) -> tuple[int, int]:
    page = coerce_int(args.get("page"), 1, minimum=1)
    page_size = coerce_int(
        args.get("page_size"),
        default_page_size,
        minimum=min(PAGE_SIZE_OPTIONS),
        maximum=max(PAGE_SIZE_OPTIONS),
    )
    if page_size not in PAGE_SIZE_OPTIONS:
        page_size = default_page_size
    return page, page_size


def build_pagination(endpoint: str, page: int, page_size: int, total_items: int, extra_args: dict[str, Any]) -> dict[str, Any]:
    total_pages = max(1, (total_items + page_size - 1) // page_size) if total_items else 1
    page = min(page, total_pages)
    filtered_args = {key: value for key, value in extra_args.items() if value not in ("", None)}
    filtered_args["page_size"] = page_size
    return {
        "page": page,
        "page_size": page_size,
        "total_items": total_items,
        "total_pages": total_pages,
        "from_item": 0 if total_items == 0 else ((page - 1) * page_size) + 1,
        "to_item": min(page * page_size, total_items),
        "prev_url": url_for(endpoint, **filtered_args, page=page - 1) if page > 1 else None,
        "next_url": url_for(endpoint, **filtered_args, page=page + 1) if page < total_pages else None,
    }


def login_required(view):
    @wraps(view)
    def wrapped(**kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login", next=request.path))
        return view(**kwargs)
    return wrapped


def edit_required(view):
    @wraps(view)
    def wrapped(**kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login", next=request.path))
        if not can_edit():
            flash("Your role is read-only.", "warning")
            return redirect(url_for("dashboard"))
        return view(**kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(**kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        if session.get("role") != "admin":
            flash("Admin access required.", "warning")
            return redirect(url_for("dashboard"))
        return view(**kwargs)
    return wrapped


def region_lookup() -> tuple[dict[str, str], dict[str, str]]:
    regions = fetch_setting("regions", DEFAULT_OPTIONS["regions"])
    alias_to_iso: dict[str, str] = {}
    iso_to_name: dict[str, str] = {}
    for r in regions:
        name = r.get("name", "")
        iso3 = r.get("iso3", "").upper()
        if name and iso3:
            iso_to_name[iso3] = name
        for alias in r.get("aliases", []):
            alias_to_iso[alias.strip().lower()] = iso3
        if name:
            alias_to_iso[name.strip().lower()] = iso3
    return alias_to_iso, iso_to_name


def normalize_region(region: str) -> tuple[str, str]:
    alias_to_iso, iso_to_name = region_lookup()
    raw = (region or "").strip()
    if not raw:
        return "", ""
    iso = alias_to_iso.get(raw.lower(), raw.upper() if len(raw) == 3 else "")
    display = iso_to_name.get(iso, raw)
    return display, iso


def resolve_time_range(args: dict[str, str] | Any) -> dict[str, str]:
    range_key = (args.get("time_range") or "30d").strip().lower()
    if range_key not in ANALYTICS_TIME_RANGES:
        range_key = "30d"

    today = datetime.now().date()
    start_date = ""
    end_date = ""

    if range_key == "custom":
        start_date = (args.get("start_date") or "").strip()
        end_date = (args.get("end_date") or "").strip()
        if start_date and end_date and start_date > end_date:
            start_date, end_date = end_date, start_date
        if not start_date and not end_date:
            range_key = "30d"

    if range_key != "custom":
        days = ANALYTICS_TIME_RANGES[range_key]["days"] or 30
        start_date = (today - timedelta(days=days - 1)).isoformat()
        end_date = today.isoformat()

    if start_date and end_date and start_date == end_date:
        label = start_date
    elif start_date and end_date:
        label = f"{start_date} to {end_date}"
    elif start_date:
        label = f"From {start_date}"
    elif end_date:
        label = f"Up to {end_date}"
    else:
        label = ANALYTICS_TIME_RANGES[range_key]["label"]

    return {
        "key": range_key,
        "label": ANALYTICS_TIME_RANGES[range_key]["label"],
        "display": label,
        "start_date": start_date,
        "end_date": end_date,
    }


def release_name_for_id(release_id: Any) -> str:
    release_pk = coerce_int(release_id, 0, minimum=0)
    if not release_pk:
        return ""
    db = get_db()
    row = db.execute("SELECT name FROM releases WHERE id=?", (release_pk,)).fetchone()
    return row["name"] if row else ""


def build_filter_chips(
    filters: dict[str, Any] | Any,
    settings: dict[str, Any],
    *,
    include_time: bool = False,
    include_release: bool = False,
    extra: list[tuple[str, str]] | None = None,
) -> list[dict[str, str]]:
    chips: list[dict[str, str]] = []
    regions = {item.get("iso3"): item.get("name") for item in settings.get("regions", [])}
    for item in settings.get("regions", []):
        name = item.get("name", "")
        iso3 = item.get("iso3", "")
        if name:
            regions[name] = name
        if iso3:
            regions[iso3] = name or iso3

    if include_time:
        time_range = resolve_time_range(filters)
        chips.append({"label": "Time range", "value": time_range["display"]})

    values = [
        ("region", "Region", regions.get((filters.get("region") or "").strip(), (filters.get("region") or "").strip())),
        ("environment", "Environment", (filters.get("environment") or "").strip()),
        ("system", "System", (filters.get("system") or "").strip()),
        ("status", "Status", (filters.get("status") or "").strip()),
        ("keyword", "Keyword", (filters.get("keyword") or "").strip()),
    ]
    if include_release:
        release_name = release_name_for_id(filters.get("release_id"))
        values.append(("release_id", "Release", release_name))

    for _, label, value in values:
        if value:
            chips.append({"label": label, "value": value})

    for label, value in extra or []:
        if value:
            chips.append({"label": label, "value": value})

    return chips


def build_filter_conditions(
    args: dict[str, str] | Any,
    include_region: bool = True,
    *,
    alias: str | None = None,
    release_alias: str | None = None,
    date_column: str | None = None,
) -> tuple[str, list[Any]]:
    normalized_filters = {
        "region": (args.get("region") or "").strip(),
        "environment": (args.get("environment") or "").strip(),
        "system": (args.get("system") or "").strip(),
        "status": (args.get("status") or "").strip(),
        "keyword": (args.get("keyword") or "").strip(),
        "release_id": coerce_int(args.get("release_id"), 0, minimum=0),
        "missing_prod": bool(args.get("missing_prod")),
        "require_release": bool(args.get("require_release")),
        "start_date": (args.get("start_date") or "").strip(),
        "end_date": (args.get("end_date") or "").strip(),
    }
    if date_column:
        time_range = resolve_time_range(args)
        normalized_filters["start_date"] = time_range["start_date"]
        normalized_filters["end_date"] = time_range["end_date"]

    return build_change_where(
        normalized_filters,
        alias=alias,
        release_alias=release_alias,
        include_region=include_region,
        date_column=date_column,
    )


def compact_query_params(values: dict[str, Any], allowed_keys: list[str]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key in allowed_keys:
        value = values.get(key)
        if value not in ("", None, False):
            result[key] = value
    return result


def assistant_filter_chips(parsed: dict[str, Any], settings: dict[str, Any]) -> list[dict[str, str]]:
    filters = parsed.get("filters", {})
    chips = build_filter_chips(filters, settings, include_time=bool(filters.get("time_range")))
    if parsed.get("intent") == "compare":
        chips.append({"label": "Comparison", "value": parsed.get("compare_env", "SIT")})
    if filters.get("missing_prod"):
        chips.append({"label": "Scope", "value": "Missing PROD only"})
    if filters.get("require_release"):
        chips.append({"label": "Scope", "value": "Release-linked only"})
    grouping_mode = (filters.get("grouping_mode") or "auto").strip().lower()
    if grouping_mode in TIME_GROUPING_OPTIONS and grouping_mode != "auto":
        chips.append({"label": "Grouping", "value": grouping_mode.capitalize()})
    return chips


def assistant_change_cards(rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
    cards = []
    for row in rows:
        cards.append({
            "title": row["jira_ref"],
            "subtitle": row["title"] or "Untitled change",
            "meta": [item for item in [row["status"], row["selected_environment"], row["system_name"], row["region"], row["release_name"]] if item],
            "detail": row["updated_at"],
            "url": url_for("view_change", change_id=row["id"]),
        })
    return cards


def assistant_release_cards(rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
    cards = []
    for row in rows:
        cards.append({
            "title": row["name"],
            "subtitle": row["description"] or "No release description provided.",
            "meta": [
                f"{row['change_count'] or 0} linked changes",
                f"{row['pending_count'] or 0} pending",
                f"{row['blocked_count'] or 0} blocked",
            ],
            "detail": row["release_date"] or row["last_change_at"] or "No date recorded",
            "url": url_for("releases_page", keyword=row["name"]),
        })
    return cards


def assistant_audit_cards(rows: list[sqlite3.Row]) -> list[dict[str, Any]]:
    cards = []
    for row in rows:
        cards.append({
            "title": f"{row['action']} by {row['username'] or 'System'}",
            "subtitle": row["details"] or f"{row['entity_type']} activity",
            "meta": [row["entity_type"], str(row["entity_id"]) if row["entity_id"] else ""],
            "detail": row["created_at"],
            "url": url_for("audit_page", keyword=row["username"] or row["action"]),
        })
    return cards


def has_time_scope(filters: dict[str, Any] | Any) -> bool:
    return bool((filters.get("time_range") or "").strip() or (filters.get("start_date") or "").strip() or (filters.get("end_date") or "").strip())


def fetch_release_rollup(filters: dict[str, Any] | Any, *, limit: int | None = None) -> list[sqlite3.Row]:
    db = get_db()
    where_sql, params = build_filter_conditions(
        filters,
        alias="c",
        release_alias="r",
        date_column="updated_at" if has_time_scope(filters) else None,
    )
    sql = f"""
        SELECT
            r.*,
            COUNT(c.id) AS change_count,
            SUM(CASE WHEN c.prod_date IS NOT NULL AND c.prod_date != '' THEN 1 ELSE 0 END) AS prod_count,
            SUM(CASE WHEN c.id IS NOT NULL AND (c.prod_date IS NULL OR c.prod_date = '') THEN 1 ELSE 0 END) AS pending_count,
            SUM(CASE WHEN c.status IN ('Failed', 'Rolled Back') THEN 1 ELSE 0 END) AS blocked_count,
            MAX(c.updated_at) AS last_change_at
        FROM releases r
        LEFT JOIN changes c ON c.release_id = r.id
        WHERE {where_sql}
        GROUP BY r.id
        ORDER BY blocked_count DESC, pending_count DESC, COALESCE(r.release_date, r.created_at) DESC, r.name
    """
    query_params = list(params)
    if limit:
        sql += "\nLIMIT ?"
        query_params.append(limit)
    return db.execute(sql, query_params).fetchall()


def fetch_audit_results(keyword: str, *, page: int = 1, page_size: int = 50) -> tuple[int, list[sqlite3.Row]]:
    db = get_db()
    where = ["1=1"]
    params: list[Any] = []
    if keyword:
        for term in keyword.split():
            like = f"%{term}%"
            where.append("(username LIKE ? OR action LIKE ? OR entity_type LIKE ? OR details LIKE ?)")
            params.extend([like, like, like, like])
    where_sql = " AND ".join(where)
    total_items = db.execute(
        f"SELECT COUNT(*) AS c FROM audit_log WHERE {where_sql}",
        params,
    ).fetchone()["c"]
    rows = db.execute(
        f"""
        SELECT *
        FROM audit_log
        WHERE {where_sql}
        ORDER BY created_at DESC
        LIMIT ? OFFSET ?
        """,
        [*params, page_size, (page - 1) * page_size],
    ).fetchall()
    return total_items, rows



def normalize_header(value: str) -> str:
    return "".join(ch.lower() for ch in (value or "") if ch.isalnum())


def detect_import_mapping(headers: list[str]) -> dict[str, str]:
    saved = fetch_setting("jira_import_mapping", {"jira_ref": "", "title": "", "description": ""}) or {}
    normalized = {header: normalize_header(header) for header in headers}
    mapping: dict[str, str] = {}
    for field, aliases in IMPORT_FIELD_ALIASES.items():
        preferred = saved.get(field, "")
        if preferred in headers:
            mapping[field] = preferred
            continue
        selected = ""
        alias_set = {normalize_header(a) for a in aliases}
        for header, norm in normalized.items():
            if norm in alias_set:
                selected = header
                break
        mapping[field] = selected
    return mapping


def read_import_csv(file_storage) -> tuple[list[str], list[dict[str, str]]]:
    raw = file_storage.read()
    if not raw:
        return [], []
    text = None
    for encoding in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            text = raw.decode(encoding)
            break
        except Exception:
            continue
    if text is None:
        text = raw.decode("utf-8", errors="ignore")
    reader = csv.DictReader(io.StringIO(text))
    headers = [h.strip() for h in (reader.fieldnames or []) if h and h.strip()]
    rows: list[dict[str, str]] = []
    for row in reader:
        cleaned = {str(k).strip(): (str(v).strip() if v is not None else "") for k, v in row.items() if k is not None}
        if any(value for value in cleaned.values()):
            rows.append(cleaned)
    return headers, rows


def create_import_preview(file_storage) -> str:
    headers, rows = read_import_csv(file_storage)
    preview_id = uuid4().hex
    payload = {
        "file_name": secure_filename(file_storage.filename or "jira_import.csv"),
        "headers": headers,
        "rows": rows,
        "created_at": now_iso(),
    }
    (PREVIEW_DIR / f"{preview_id}.json").write_text(json.dumps(payload), encoding="utf-8")
    return preview_id


def load_import_preview(preview_id: str) -> dict[str, Any] | None:
    if not preview_id:
        return None
    path = PREVIEW_DIR / f"{preview_id}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def build_import_preview(preview: dict[str, Any], form_data: Any | None = None) -> dict[str, Any]:
    headers = preview.get("headers", [])
    mapping = detect_import_mapping(headers)
    if form_data:
        for field in ("jira_ref", "title", "description"):
            value = form_data.get(f"map_{field}", "")
            if value in headers or value == "":
                mapping[field] = value
    db = get_db()
    mapped_rows: list[dict[str, Any]] = []
    jira_refs: list[str] = []
    for idx, raw_row in enumerate(preview.get("rows", [])):
        jira_ref = (raw_row.get(mapping.get("jira_ref", ""), "") if mapping.get("jira_ref") else "").strip()
        title = (raw_row.get(mapping.get("title", ""), "") if mapping.get("title") else "").strip()
        description = (raw_row.get(mapping.get("description", ""), "") if mapping.get("description") else "").strip()
        system_name = (form_data.get(f"row_{idx}_system_name", "") if form_data else "").strip()
        region = (form_data.get(f"row_{idx}_region", "") if form_data else "").strip()
        selected_environment = (form_data.get(f"row_{idx}_selected_environment", "") if form_data else "").strip()
        release_id = (form_data.get(f"row_{idx}_release_id", "") if form_data else "").strip()
        status = (form_data.get(f"row_{idx}_status", "") if form_data else "").strip()
        deployed_by = (
            form_data.get(f"row_{idx}_deployed_by", session.get("username", ""))
            if form_data
            else session.get("username", "")
        ).strip()
        if jira_ref:
            jira_refs.append(jira_ref)
        mapped_rows.append({
            "index": idx,
            "jira_ref": jira_ref,
            "title": title,
            "description": description,
            "system_name": system_name,
            "region": region,
            "selected_environment": selected_environment,
            "release_id": release_id,
            "status": status,
            "deployed_by": deployed_by,
            "valid": bool(jira_ref),
        })
    duplicates: dict[str, Any] = {}
    if jira_refs:
        placeholders = ",".join(["?"] * len(jira_refs))
        existing = db.execute(
            f"SELECT id, jira_ref, title, selected_environment, status FROM changes WHERE jira_ref IN ({placeholders})",
            jira_refs,
        ).fetchall()
        duplicates = {row["jira_ref"]: row for row in existing}
    duplicate_count = 0
    for row in mapped_rows:
        existing = duplicates.get(row["jira_ref"]) if row["jira_ref"] else None
        row["duplicate"] = bool(existing)
        row["existing_id"] = existing["id"] if existing else None
        row["existing_title"] = existing["title"] if existing else ""
        row["existing_status"] = existing["status"] if existing else ""
        row["existing_environment"] = existing["selected_environment"] if existing else ""
        if existing:
            duplicate_count += 1
    return {
        "preview_id": preview.get("preview_id"),
        "file_name": preview.get("file_name", "jira_import.csv"),
        "headers": headers,
        "mapping": mapping,
        "rows": mapped_rows,
        "row_count": len(mapped_rows),
        "valid_count": sum(1 for row in mapped_rows if row["valid"]),
        "duplicate_count": duplicate_count,
        "invalid_count": sum(1 for row in mapped_rows if not row["valid"]),
    }


def create_change_record(payload: dict[str, Any]) -> int:
    db = get_db()
    cur = db.execute(
        """
        INSERT INTO changes (
            jira_ref, title, selected_environment, system_name, change_type, status, version,
            region, region_iso3, deployed_by, description, old_value, new_value,
            dev_date, sit_date, uat_date, preprod_date, mig_date, prod_date, release_id,
            created_by, updated_by, created_at, updated_at
        ) VALUES (
            :jira_ref, :title, :selected_environment, :system_name, :change_type, :status, :version,
            :region, :region_iso3, :deployed_by, :description, :old_value, :new_value,
            :dev_date, :sit_date, :uat_date, :preprod_date, :mig_date, :prod_date, :release_id,
            :created_by, :updated_by, :created_at, :updated_at
        )
        """,
        payload,
    )
    db.commit()
    return cur.lastrowid


def update_change_record(change_id: int, payload: dict[str, Any]) -> None:
    db = get_db()
    db.execute(
        """
        UPDATE changes SET
            jira_ref=:jira_ref, title=:title, selected_environment=:selected_environment,
            system_name=:system_name, change_type=:change_type, status=:status, version=:version,
            region=:region, region_iso3=:region_iso3, deployed_by=:deployed_by, description=:description,
            old_value=:old_value, new_value=:new_value, dev_date=:dev_date, sit_date=:sit_date, uat_date=:uat_date,
            preprod_date=:preprod_date, mig_date=:mig_date, prod_date=:prod_date, release_id=:release_id, updated_by=:updated_by,
            updated_at=:updated_at
        WHERE id=:id
        """,
        {**payload, "id": change_id},
    )
    db.commit()


def get_import_history(limit: int = 8):
    db = get_db()
    return db.execute("SELECT * FROM import_history ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()

def row_to_dict(row: sqlite3.Row) -> dict[str, Any]:
    return {k: row[k] for k in row.keys()}


def empty_chart() -> dict[str, list[Any]]:
    return {"labels": ["No data"], "data": [1]}


def table_rows(rows: list[sqlite3.Row], max_rows: int = 8) -> list[dict[str, Any]]:
    return [row_to_dict(r) for r in rows[:max_rows]]


def recent_activity(limit: int = 8, username: str | None = None) -> list[dict[str, Any]]:
    db = get_db()
    where = ["1=1"]
    params: list[Any] = []
    if username:
        where.append("username = ?")
        params.append(username)
    rows = db.execute(
        f"SELECT username, action, entity_type, entity_id, details, created_at FROM audit_log WHERE {' AND '.join(where)} ORDER BY created_at DESC LIMIT ?",
        [*params, limit],
    ).fetchall()
    return [row_to_dict(r) for r in rows]


def build_dashboard_snapshot(filters: dict[str, str]) -> dict[str, Any]:
    db = get_db()
    where_sql, params = build_filter_conditions(filters, alias="c", release_alias="r")
    attention_clause = """
        c.status IN ('Failed', 'Rolled Back')
        OR (
            (c.prod_date IS NULL OR c.prod_date = '')
            AND (c.dev_date IS NOT NULL OR c.sit_date IS NOT NULL OR c.uat_date IS NOT NULL OR c.preprod_date IS NOT NULL OR c.mig_date IS NOT NULL)
        )
        OR (
            (c.prod_date IS NULL OR c.prod_date = '')
            AND date(c.updated_at) <= date('now', '-7 day')
        )
    """

    kpis = {
        "attention": db.execute(
            f"SELECT COUNT(*) AS c FROM changes c LEFT JOIN releases r ON r.id = c.release_id WHERE {where_sql} AND ({attention_clause})",
            params,
        ).fetchone()["c"],
        "missing_prod": db.execute(
            f"""
            SELECT COUNT(*) AS c
            FROM changes c
            LEFT JOIN releases r ON r.id = c.release_id
            WHERE {where_sql}
              AND (c.prod_date IS NULL OR c.prod_date = '')
              AND (c.dev_date IS NOT NULL OR c.sit_date IS NOT NULL OR c.uat_date IS NOT NULL OR c.preprod_date IS NOT NULL OR c.mig_date IS NOT NULL)
            """,
            params,
        ).fetchone()["c"],
        "failed": db.execute(
            f"SELECT COUNT(*) AS c FROM changes c LEFT JOIN releases r ON r.id = c.release_id WHERE {where_sql} AND c.status IN ('Failed', 'Rolled Back')",
            params,
        ).fetchone()["c"],
        "updated_24h": db.execute(
            f"SELECT COUNT(*) AS c FROM changes c LEFT JOIN releases r ON r.id = c.release_id WHERE {where_sql} AND datetime(c.updated_at) >= datetime('now', '-1 day')",
            params,
        ).fetchone()["c"],
    }

    recent_changes = db.execute(
        f"""
        SELECT c.id, c.jira_ref, COALESCE(c.title, '') AS title, c.status, c.selected_environment, c.system_name,
               c.region, c.updated_at, r.name AS release_name
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql}
        ORDER BY c.updated_at DESC
        LIMIT 8
        """,
        params,
    ).fetchall()
    recent_failures = db.execute(
        f"""
        SELECT c.id, c.jira_ref, COALESCE(c.title, '') AS title, c.status, c.selected_environment, c.updated_at
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql} AND c.status IN ('Failed', 'Rolled Back')
        ORDER BY c.updated_at DESC
        LIMIT 6
        """,
        params,
    ).fetchall()

    region_health = db.execute(
        f"""
        SELECT COALESCE(NULLIF(c.region, ''), 'Unassigned') AS label,
               COUNT(*) AS total,
               SUM(CASE WHEN c.status IN ('Failed', 'Rolled Back') THEN 1 ELSE 0 END) AS blockers,
               SUM(CASE WHEN (c.prod_date IS NULL OR c.prod_date = '') AND (c.dev_date IS NOT NULL OR c.sit_date IS NOT NULL OR c.uat_date IS NOT NULL OR c.preprod_date IS NOT NULL OR c.mig_date IS NOT NULL) THEN 1 ELSE 0 END) AS watch_count,
               SUM(CASE WHEN c.prod_date IS NOT NULL AND c.prod_date != '' THEN 1 ELSE 0 END) AS healthy
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql}
        GROUP BY COALESCE(NULLIF(c.region, ''), 'Unassigned')
        ORDER BY blockers DESC, watch_count DESC, total DESC, label
        LIMIT 6
        """,
        params,
    ).fetchall()
    system_health = db.execute(
        f"""
        SELECT COALESCE(NULLIF(c.system_name, ''), 'Unassigned') AS label,
               COUNT(*) AS total,
               SUM(CASE WHEN c.status IN ('Failed', 'Rolled Back') THEN 1 ELSE 0 END) AS blockers,
               SUM(CASE WHEN (c.prod_date IS NULL OR c.prod_date = '') AND (c.dev_date IS NOT NULL OR c.sit_date IS NOT NULL OR c.uat_date IS NOT NULL OR c.preprod_date IS NOT NULL OR c.mig_date IS NOT NULL) THEN 1 ELSE 0 END) AS watch_count,
               SUM(CASE WHEN c.prod_date IS NOT NULL AND c.prod_date != '' THEN 1 ELSE 0 END) AS healthy
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql}
        GROUP BY COALESCE(NULLIF(c.system_name, ''), 'Unassigned')
        ORDER BY blockers DESC, watch_count DESC, total DESC, label
        LIMIT 6
        """,
        params,
    ).fetchall()
    systems_this_week = db.execute(
        f"""
        SELECT COALESCE(NULLIF(c.system_name, ''), 'Unassigned') AS label, COUNT(*) AS count
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql} AND datetime(c.updated_at) >= datetime('now', '-7 day')
        GROUP BY COALESCE(NULLIF(c.system_name, ''), 'Unassigned')
        ORDER BY count DESC, label
        LIMIT 6
        """,
        params,
    ).fetchall()

    release_blockers = []
    active_releases = 0
    blocked_releases = 0
    if plugin_enabled("releases"):
        release_rollup = db.execute(
            f"""
            SELECT r.id, r.name, r.release_date,
                   COUNT(c.id) AS total_changes,
                   SUM(CASE WHEN c.id IS NOT NULL AND (c.prod_date IS NULL OR c.prod_date = '') THEN 1 ELSE 0 END) AS pending_count,
                   SUM(CASE WHEN c.status IN ('Failed', 'Rolled Back') THEN 1 ELSE 0 END) AS blocked_count,
                   MAX(c.updated_at) AS last_change_at
            FROM releases r
            JOIN changes c ON c.release_id = r.id
            WHERE {where_sql}
            GROUP BY r.id
            ORDER BY blocked_count DESC, pending_count DESC, COALESCE(r.release_date, r.created_at), r.name
            """,
            params,
        ).fetchall()
        release_blockers = [row_to_dict(row) for row in release_rollup[:6]]
        active_releases = sum(1 for row in release_rollup if (row["pending_count"] or 0) > 0)
        blocked_releases = sum(1 for row in release_rollup if (row["blocked_count"] or 0) > 0)

    planned_rows = db.execute(
        f"""
        SELECT c.id, c.jira_ref, COALESCE(c.title, '') AS title, c.status, c.system_name,
               c.selected_environment, c.dev_date, c.sit_date, c.uat_date, c.preprod_date, c.mig_date, c.prod_date,
               r.name AS release_name
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql} AND c.status IN ('Planned', 'In Progress', 'Ready for PROD')
        ORDER BY c.updated_at DESC
        LIMIT 40
        """,
        params,
    ).fetchall()
    upcoming_planned: list[dict[str, Any]] = []
    today = today_iso()
    for row in planned_rows:
        item = row_to_dict(row)
        future_dates = [
            value for value in [
                row["dev_date"],
                row["sit_date"],
                row["uat_date"],
                row["preprod_date"],
                row["mig_date"],
                row["prod_date"],
            ]
            if value and value >= today
        ]
        item["next_target_date"] = min(future_dates) if future_dates else ""
        upcoming_planned.append(item)
    upcoming_planned.sort(key=lambda item: (item["next_target_date"] or "9999-12-31", item["jira_ref"]))

    return {
        "kpis": {
            **kpis,
            "active_releases": active_releases,
            "blocked_releases": blocked_releases,
        },
        "recent_activity": recent_activity(8),
        "my_activity": recent_activity(5, session.get("username")),
        "recent_changes": [row_to_dict(row) for row in recent_changes],
        "recent_failures": [row_to_dict(row) for row in recent_failures],
        "region_health": [row_to_dict(row) for row in region_health],
        "system_health": [row_to_dict(row) for row in system_health],
        "systems_this_week": [row_to_dict(row) for row in systems_this_week],
        "release_blockers": release_blockers,
        "upcoming_planned": upcoming_planned[:6],
    }


def build_analytics_payload(args: dict[str, str] | Any) -> dict[str, Any]:
    db = get_db()
    statuses = fetch_setting("statuses", DEFAULT_OPTIONS["statuses"])
    environments = fetch_setting("environments", DEFAULT_OPTIONS["environments"])
    time_range = resolve_time_range(args)
    where_sql, params = build_filter_conditions(args, alias="c", date_column="updated_at")
    grouping = resolve_chart_grouping(
        {"grouping_mode": (args.get("grouping_mode") or "auto")},
        time_range["start_date"] or today_iso(),
        time_range["end_date"] or today_iso(),
    )

    total = db.execute(f"SELECT COUNT(*) AS c FROM changes c WHERE {where_sql}", params).fetchone()["c"]
    success = db.execute(
        f"SELECT COUNT(*) AS c FROM changes c WHERE {where_sql} AND (c.status='Deployed' OR (c.prod_date IS NOT NULL AND c.prod_date != ''))",
        params,
    ).fetchone()["c"]
    failed = db.execute(
        f"SELECT COUNT(*) AS c FROM changes c WHERE {where_sql} AND c.status IN ('Failed', 'Rolled Back')",
        params,
    ).fetchone()["c"]
    missing_prod = db.execute(
        f"""
        SELECT COUNT(*) AS c
        FROM changes c
        WHERE {where_sql}
          AND (c.prod_date IS NULL OR c.prod_date = '')
          AND (c.dev_date IS NOT NULL OR c.sit_date IS NOT NULL OR c.uat_date IS NOT NULL OR c.preprod_date IS NOT NULL OR c.mig_date IS NOT NULL)
        """,
        params,
    ).fetchone()["c"]

    status_rows = db.execute(
        f"""
        SELECT COALESCE(c.status, 'Unspecified') AS label, COUNT(*) AS count
        FROM changes c
        WHERE {where_sql}
        GROUP BY COALESCE(c.status, 'Unspecified')
        ORDER BY count DESC, label
        """,
        params,
    ).fetchall()
    env_rows = db.execute(
        f"""
        SELECT COALESCE(c.selected_environment, 'Unspecified') AS label, COUNT(*) AS count
        FROM changes c
        WHERE {where_sql}
        GROUP BY COALESCE(c.selected_environment, 'Unspecified')
        ORDER BY count DESC, label
        """,
        params,
    ).fetchall()
    region_rows = db.execute(
        f"""
        SELECT COALESCE(NULLIF(c.region, ''), 'Unassigned') AS label, COUNT(*) AS count
        FROM changes c
        WHERE {where_sql}
        GROUP BY COALESCE(NULLIF(c.region, ''), 'Unassigned')
        ORDER BY count DESC, label
        LIMIT 8
        """,
        params,
    ).fetchall()
    system_rows = db.execute(
        f"""
        SELECT COALESCE(NULLIF(c.system_name, ''), 'Unassigned') AS label, COUNT(*) AS count
        FROM changes c
        WHERE {where_sql}
        GROUP BY COALESCE(NULLIF(c.system_name, ''), 'Unassigned')
        ORDER BY count DESC, label
        LIMIT 8
        """,
        params,
    ).fetchall()
    deployer_rows = db.execute(
        f"""
        SELECT COALESCE(NULLIF(c.deployed_by, ''), 'Unassigned') AS label, COUNT(*) AS count
        FROM changes c
        WHERE {where_sql}
        GROUP BY COALESCE(NULLIF(c.deployed_by, ''), 'Unassigned')
        ORDER BY count DESC, label
        LIMIT 8
        """,
        params,
    ).fetchall()
    daily_rows = db.execute(
        f"""
        SELECT date(c.updated_at) AS label,
               COUNT(*) AS count,
               SUM(CASE WHEN c.status IN ('Failed', 'Rolled Back') THEN 1 ELSE 0 END) AS failed_count,
               SUM(CASE WHEN c.status = 'Deployed' OR (c.prod_date IS NOT NULL AND c.prod_date != '') THEN 1 ELSE 0 END) AS success_count
        FROM changes c
        WHERE {where_sql}
        GROUP BY date(c.updated_at)
        ORDER BY date(c.updated_at)
        """,
        params,
    ).fetchall()
    grouped_volume = bucket_time_series([dict(row) for row in daily_rows], grouping, ["count"])
    grouped_success_failure = bucket_time_series([dict(row) for row in daily_rows], grouping, ["success_count", "failed_count"])
    stale_rows = db.execute(
        f"""
        SELECT c.id, c.jira_ref, COALESCE(c.title, '') AS title, c.status, c.selected_environment, c.updated_at
        FROM changes c
        WHERE {where_sql}
          AND (c.prod_date IS NULL OR c.prod_date = '')
          AND date(c.updated_at) <= date('now', '-7 day')
        ORDER BY c.updated_at ASC
        LIMIT 10
        """,
        params,
    ).fetchall()
    dev_only_rows = db.execute(
        f"""
        SELECT c.id, c.jira_ref, COALESCE(c.title, '') AS title, c.deployed_by, c.status, c.updated_at
        FROM changes c
        WHERE {where_sql}
          AND c.dev_date IS NOT NULL AND c.dev_date != ''
          AND (c.prod_date IS NULL OR c.prod_date = '')
        ORDER BY c.updated_at DESC
        LIMIT 10
        """,
        params,
    ).fetchall()
    drift_rows = db.execute(
        f"""
        SELECT c.id, c.jira_ref, COALESCE(c.title, '') AS title, c.region, c.selected_environment, c.status, c.updated_at
        FROM changes c
        WHERE {where_sql}
          AND c.prod_date IS NOT NULL AND c.prod_date != ''
          AND (
            (c.selected_environment='DEV' AND (c.dev_date IS NULL OR c.dev_date='')) OR
            (c.selected_environment='SIT' AND (c.sit_date IS NULL OR c.sit_date='')) OR
            (c.selected_environment='UAT' AND (c.uat_date IS NULL OR c.uat_date='')) OR
            (c.selected_environment='PREPROD' AND (c.preprod_date IS NULL OR c.preprod_date='')) OR
            (c.selected_environment='MIG' AND (c.mig_date IS NULL OR c.mig_date=''))
          )
        ORDER BY c.updated_at DESC
        LIMIT 10
        """,
        params,
    ).fetchall()

    matrix_datasets = []
    for status in statuses:
        counts = []
        for env in environments:
            count = db.execute(
                f"SELECT COUNT(*) AS c FROM changes c WHERE {where_sql} AND c.status=? AND c.selected_environment=?",
                [*params, status, env],
            ).fetchone()["c"]
            counts.append(count)
        matrix_datasets.append({"label": status, "data": counts})

    return {
        "summary": {
            "total": total,
            "success": success,
            "failed": failed,
            "missing_prod": missing_prod,
            "stale": len(stale_rows),
        },
        "grouping": grouping,
        "status_chart": {"labels": [row["label"] for row in status_rows], "data": [row["count"] for row in status_rows]} if status_rows else empty_chart(),
        "env_chart": {"labels": [row["label"] for row in env_rows], "data": [row["count"] for row in env_rows]} if env_rows else empty_chart(),
        "region_chart": {"labels": [row["label"] for row in region_rows], "data": [row["count"] for row in region_rows]} if region_rows else empty_chart(),
        "system_chart": {"labels": [row["label"] for row in system_rows], "data": [row["count"] for row in system_rows]} if system_rows else empty_chart(),
        "deployer_chart": {"labels": [row["label"] for row in deployer_rows], "data": [row["count"] for row in deployer_rows]} if deployer_rows else empty_chart(),
        "volume_chart": {"labels": [row["label"] for row in grouped_volume], "data": [row["count"] for row in grouped_volume]} if grouped_volume else empty_chart(),
        "success_failure_trend": {
            "labels": [row["label"] for row in grouped_success_failure] or ["No data"],
            "datasets": [
                {"label": "Successful", "data": [row["success_count"] for row in grouped_success_failure] or [0]},
                {"label": "Failed / Rolled Back", "data": [row["failed_count"] for row in grouped_success_failure] or [0]},
            ],
        },
        "matrix": {"labels": environments or ["No environment"], "datasets": matrix_datasets},
        "stale": table_rows(list(stale_rows), 10),
        "dev_only": table_rows(list(dev_only_rows), 10),
        "drift": table_rows(list(drift_rows), 10),
        "recent_activity": recent_activity(8),
    }


@app.before_request
def run_plugin_jobs():
    if request.endpoint not in {'static'}:
        maybe_run_scheduled_sync()


@app.context_processor
def inject_global_context():
    security = security_summary() if session.get("role") == "admin" else {}
    command_bar_value = (
        (request.args.get("assistant_query") or "").strip()
        or (request.args.get("q") or "").strip()
        or (request.args.get("keyword") or "").strip()
    )
    return {
        "app_settings": get_context_settings(),
        "current_year": datetime.now().year,
        "current_user": current_user(),
        "can_edit": can_edit(),
        "plugins": get_plugins(),
        "notifications": fetch_notifications(6) if session.get("user_id") else [],
        "security_banner": (
            "The default admin password is still active. Change it in Settings to secure the app."
            if security.get("default_admin_password_active")
            else ""
        ),
        "command_bar_value": command_bar_value,
        "assistant_query": (request.args.get("assistant_query") or "").strip(),
        "status_badge_class": status_badge_class,
        "risk_badge_class": risk_badge_class,
        "badge_soft_class": badge_soft_class,
    }


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        db = get_db()
        user = db.execute(
            "SELECT * FROM users WHERE username=? AND is_active=1", (username,)
        ).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session.update({"user_id": user["id"], "username": user["username"], "role": user["role"]})
            session.permanent = True
            log_audit("login", "session", user["id"], "Successful login")
            flash(f"Welcome back, {user['username']}.", "success")
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Invalid username or password.", "danger")
    return render_template("login.html", security=security_summary())


@app.route("/logout")
@login_required
def logout():
    log_audit("logout", "session", session.get("user_id"), "User logged out")
    session.clear()
    flash("Signed out.", "info")
    return redirect(url_for("login"))


@app.route("/account", methods=["GET", "POST"])
@login_required
def account_page():
    db = get_db()
    user = db.execute(
        "SELECT id, username, role, created_at, is_active, password_hash FROM users WHERE id=?",
        (session.get("user_id"),),
    ).fetchone()
    if not user or not user["is_active"]:
        session.clear()
        flash("Your account is no longer active.", "warning")
        return redirect(url_for("login"))

    if request.method == "POST":
        current_password = request.form.get("current_password", "")
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")

        if not check_password_hash(user["password_hash"], current_password):
            flash("Your current password is incorrect.", "warning")
        elif len(new_password) < 8:
            flash("New passwords must be at least 8 characters long.", "warning")
        elif new_password != confirm_password:
            flash("The new password and confirmation do not match.", "warning")
        elif current_password == new_password:
            flash("Choose a new password that is different from your current password.", "warning")
        else:
            db.execute(
                "UPDATE users SET password_hash=? WHERE id=?",
                (generate_password_hash(new_password), user["id"]),
            )
            db.commit()
            log_audit("update", "user", user["id"], f"Changed password for {user['username']}")
            flash("Your password has been updated.", "success")
            return redirect(url_for("account_page"))

    return render_template(
        "account.html",
        account_user=user,
        security=security_summary(),
    )


@app.route("/")
@login_required
def dashboard():
    settings = get_context_settings()
    filters = {
        "region": request.args.get("region", ""),
        "environment": request.args.get("environment", ""),
        "system": request.args.get("system", ""),
        "status": request.args.get("status", ""),
        "keyword": request.args.get("keyword", "").strip(),
    }
    scope_filters = {key: value for key, value in filters.items() if value}
    presets = [
        {"label": "Failed items", "url": url_for("dashboard", status="Failed")},
        {"label": "Missing PROD", "url": url_for("compare_envs", compare_env="DEV")},
        {"label": "Ready for PROD", "url": url_for("dashboard", status="Ready for PROD")},
        {"label": "Open analytics", "url": url_for("analytics_page", **scope_filters)},
    ]
    return render_template(
        "dashboard.html",
        settings=settings,
        filters=filters,
        dashboard_data=build_dashboard_snapshot(filters),
        filter_chips=build_filter_chips(filters, settings),
        clear_filters_url=url_for("dashboard"),
        dashboard_presets=presets,
        analytics_scope_url=url_for("analytics_page", **scope_filters),
        changes_scope_url=url_for("changes_page", **scope_filters),
    )


@app.route("/analytics")
@login_required
def analytics_page():
    settings = get_context_settings()
    filters = {
        "time_range": request.args.get("time_range", "30d"),
        "start_date": request.args.get("start_date", ""),
        "end_date": request.args.get("end_date", ""),
        "grouping_mode": request.args.get("grouping_mode", "auto"),
        "region": request.args.get("region", ""),
        "environment": request.args.get("environment", ""),
        "system": request.args.get("system", ""),
        "status": request.args.get("status", ""),
        "keyword": request.args.get("keyword", "").strip(),
    }
    presets = [
        {"label": "Last 7 days", "url": url_for("analytics_page", time_range="7d")},
        {"label": "Failed changes", "url": url_for("analytics_page", time_range="30d", status="Failed")},
        {"label": "Missing PROD", "url": url_for("analytics_page", time_range="30d", status="Ready for PROD")},
        {"label": "Drift watch", "url": url_for("analytics_page", time_range="90d", environment="DEV")},
    ]
    return render_template(
        "analytics.html",
        settings=settings,
        filters=filters,
        time_range=resolve_time_range(filters),
        filter_chips=build_filter_chips(filters, settings, include_time=True),
        clear_filters_url=url_for("analytics_page"),
        analytics_presets=presets,
        grouping_options=TIME_GROUPING_OPTIONS,
    )


@app.route("/search")
@login_required
def global_search():
    q = request.args.get("q", "").strip()
    if not q:
        return redirect(url_for("changes_page"))
    settings = get_context_settings()
    parsed = parse_natural_language_query(q, settings)
    filters = parsed["filters"]
    assistant_mode = parsed.get("assistant_mode")

    if parsed["intent"] == "audit":
        audit_keyword = parsed.get("residual_text") or " ".join(
            value for value in [filters.get("status"), filters.get("system"), filters.get("region")] if value
        ).strip() or q.replace("audit", "").replace("activity", "").strip() or q
        params = {"keyword": audit_keyword}
        if assistant_mode:
            params["assistant_query"] = q
        return redirect(url_for("audit_page", **params))

    if parsed["intent"] == "compare":
        params = compact_query_params(filters, ["region", "system", "status", "release_id", "keyword"])
        params["compare_env"] = parsed.get("compare_env", "SIT")
        if assistant_mode:
            params["assistant_query"] = q
        return redirect(url_for("compare_envs", **params))

    if parsed["intent"] == "releases":
        params = compact_query_params(filters, ["region", "system", "status", "keyword", "time_range", "start_date", "end_date"])
        if assistant_mode:
            params["assistant_query"] = q
        return redirect(url_for("releases_page", **params))

    if parsed["intent"] == "analytics":
        params = compact_query_params(filters, ["region", "environment", "system", "status", "keyword", "time_range", "start_date", "end_date", "grouping_mode"])
        if "time_range" not in params:
            params["time_range"] = "30d"
        if assistant_mode:
            params["assistant_query"] = q
        return redirect(url_for("analytics_page", **params))

    params = compact_query_params(filters, ["region", "environment", "system", "status", "keyword", "release_id"])
    if assistant_mode:
        params["assistant_query"] = q
    return redirect(url_for("changes_page", **params))


@app.route("/api/assistant/query", methods=["GET", "POST"])
@login_required
def assistant_query():
    payload = request.get_json(silent=True) or {}
    q = (payload.get("q") or request.values.get("q") or "").strip()
    if not q:
        return jsonify({
            "summary": "Ask about changes, releases, missing PROD, drift, or audit activity.",
            "cards": [],
            "links": [],
            "chips": [],
            "grounding_note": "Results are grounded only in records stored in this app.",
        })

    settings = get_context_settings()
    parsed = parse_natural_language_query(q, settings)
    filters = parsed["filters"]
    db = get_db()
    chips = assistant_filter_chips(parsed, settings)
    cards: list[dict[str, Any]] = []
    links: list[dict[str, str]] = []
    summary = "No matching records found."
    total_matches = 0

    if parsed["intent"] == "audit":
        audit_keyword = parsed.get("residual_text") or " ".join(
            value for value in [filters.get("status"), filters.get("system"), filters.get("region")] if value
        ).strip() or q
        total_matches, rows = fetch_audit_results(audit_keyword, page=1, page_size=8)
        cards = assistant_audit_cards(list(rows))
        summary = f"Found {total_matches} matching audit event{'s' if total_matches != 1 else ''}."
        links = [{"label": "Open Activity & Audit", "url": url_for("audit_page", keyword=audit_keyword)}]
    elif parsed["intent"] == "releases" or filters.get("require_release"):
        rows = fetch_release_rollup(filters)
        total_matches = len(rows)
        cards = assistant_release_cards(list(rows[:8]))
        summary = f"Found {total_matches} matching release group{'s' if total_matches != 1 else ''}."
        links = [
            {"label": "Open Releases", "url": url_for("releases_page", **compact_query_params(filters, ['region', 'system', 'status', 'keyword', 'time_range', 'start_date', 'end_date']))},
            {"label": "Open Change Logger", "url": url_for("changes_page", **compact_query_params(filters, ['region', 'environment', 'system', 'status', 'keyword', 'release_id']))},
        ]
    else:
        query_filters = dict(filters)
        use_date_scope = bool(filters.get("time_range") or filters.get("start_date") or filters.get("end_date") or parsed["intent"] == "analytics")
        where_sql, params = build_filter_conditions(
            query_filters,
            alias="c",
            release_alias="r",
            date_column="updated_at" if use_date_scope else None,
        )
        if parsed["intent"] == "compare":
            compare_env = parsed.get("compare_env", "SIT")
            compare_col = ENV_COLUMNS.get(compare_env, "sit_date")
            extra_where = [f"(c.{compare_col} IS NOT NULL AND c.{compare_col} != '')", "(c.prod_date IS NULL OR c.prod_date = '')"]
            total_matches = db.execute(
                f"SELECT COUNT(*) AS c FROM changes c LEFT JOIN releases r ON r.id = c.release_id WHERE {where_sql} AND {' AND '.join(extra_where)}",
                params,
            ).fetchone()["c"]
            rows = db.execute(
                f"""
                SELECT c.*, r.name AS release_name
                FROM changes c
                LEFT JOIN releases r ON r.id = c.release_id
                WHERE {where_sql} AND {' AND '.join(extra_where)}
                ORDER BY c.updated_at DESC
                LIMIT 8
                """,
                params,
            ).fetchall()
            summary = f"Found {total_matches} record{'s' if total_matches != 1 else ''} in {compare_env} but not yet in PROD."
            links = [
                {"label": "Open Environment Comparison", "url": url_for("compare_envs", compare_env=compare_env, **compact_query_params(filters, ['region', 'system', 'status', 'keyword', 'release_id']))},
                {"label": "Open Change Logger", "url": url_for("changes_page", **compact_query_params(filters, ['region', 'environment', 'system', 'status', 'keyword', 'release_id']))},
            ]
            cards = assistant_change_cards(list(rows))
        else:
            total_matches = db.execute(
                f"SELECT COUNT(*) AS c FROM changes c LEFT JOIN releases r ON r.id = c.release_id WHERE {where_sql}",
                params,
            ).fetchone()["c"]
            rows = db.execute(
                f"""
                SELECT c.*, r.name AS release_name
                FROM changes c
                LEFT JOIN releases r ON r.id = c.release_id
                WHERE {where_sql}
                ORDER BY c.updated_at DESC
                LIMIT 8
                """,
                params,
            ).fetchall()
            cards = assistant_change_cards(list(rows))
            if parsed["intent"] == "analytics":
                analytics_payload = build_analytics_payload(filters)
                summary = (
                    f"Found {analytics_payload['summary']['total']} matching change records. "
                    f"{analytics_payload['summary']['failed']} failed or rolled back, "
                    f"{analytics_payload['summary']['missing_prod']} missing PROD, "
                    f"grouped {analytics_payload['grouping']['mode']} for trend charts."
                )
                links = [
                    {"label": "Open Analytics", "url": url_for("analytics_page", **compact_query_params(filters, ['region', 'environment', 'system', 'status', 'keyword', 'time_range', 'start_date', 'end_date', 'grouping_mode']))},
                    {"label": "Open Change Logger", "url": url_for("changes_page", **compact_query_params(filters, ['region', 'environment', 'system', 'status', 'keyword', 'release_id']))},
                ]
            else:
                summary = f"Found {total_matches} matching change record{'s' if total_matches != 1 else ''}."
                links = [
                    {"label": "Open Change Logger", "url": url_for("changes_page", **compact_query_params(filters, ['region', 'environment', 'system', 'status', 'keyword', 'release_id']))},
                    {"label": "Open Analytics", "url": url_for("analytics_page", **compact_query_params(filters, ['region', 'environment', 'system', 'status', 'keyword']))},
                ]
                if filters.get("missing_prod"):
                    links.append({"label": "Open Environment Comparison", "url": url_for("compare_envs", compare_env="DEV", **compact_query_params(filters, ['region', 'system', 'status', 'keyword', 'release_id']))})

    if not cards and total_matches == 0:
        summary = "No matching records found."

    return jsonify({
        "intent": parsed["intent"],
        "summary": summary,
        "cards": cards,
        "links": links,
        "chips": chips,
        "query": q,
        "grounding_note": "Results are grounded only in the current database records and filters parsed from your request.",
    })


@app.route("/api/map-data")
@login_required
def api_map_data():
    db = get_db()
    statuses = fetch_setting("statuses", DEFAULT_OPTIONS["statuses"])
    where_sql, params = build_filter_conditions(request.args, alias="c", date_column="updated_at")
    rows = db.execute(
        f"""
        SELECT COALESCE(NULLIF(c.region_iso3,''), c.region) AS region_key,
               COALESCE(c.status,'Unspecified') AS status,
               COUNT(*) AS c,
               SUM(CASE WHEN c.prod_date IS NOT NULL AND c.prod_date != '' THEN 1 ELSE 0 END) AS prod_c
        FROM changes c
        WHERE {where_sql}
          AND COALESCE(NULLIF(c.region_iso3,''), c.region) IS NOT NULL
          AND COALESCE(NULLIF(c.region_iso3,''), c.region) != ''
        GROUP BY COALESCE(NULLIF(c.region_iso3,''), c.region), COALESCE(c.status,'Unspecified')
        """,
        params,
    ).fetchall()

    payload: dict[str, Any] = {}
    for row in rows:
        key = row["region_key"]
        stats = payload.setdefault(key, {"total": 0, "prod": 0, "status_counts": {s: 0 for s in statuses}})
        stats["total"] += row["c"]
        stats["prod"] += row["prod_c"]
        stats["status_counts"][row["status"]] = row["c"]
    return jsonify(payload)


@app.route("/api/analytics-data")
@app.route("/api/dashboard-data")
@login_required
def api_dashboard_data():
    return jsonify(build_analytics_payload(request.args))


@app.route("/changes", methods=["GET", "POST"])
@login_required
def changes_page():
    db = get_db()
    settings = get_context_settings()
    preview_context = None

    if request.method == "POST":
        action = request.form.get("action", "create_change")

        if action == "create_change":
            if not can_edit():
                flash("Your role is read-only.", "warning")
                return redirect(url_for("changes_page"))
            form = request.form
            title = form.get("title", "").strip()
            jira_ref = form.get("jira_ref", "").strip()
            if not jira_ref:
                flash("JIRA reference is required.", "danger")
                return redirect(url_for("changes_page"))

            region_display, region_iso3 = normalize_region(form.get("region", ""))
            ts = now_iso()
            payload = {
                "jira_ref": jira_ref,
                "title": title,
                "selected_environment": form.get("selected_environment", ""),
                "system_name": form.get("system_name", ""),
                "change_type": form.get("change_type", ""),
                "status": form.get("status", ""),
                "version": form.get("version", "").strip(),
                "region": region_display,
                "region_iso3": region_iso3,
                "deployed_by": form.get("deployed_by", ""),
                "description": form.get("description", "").strip(),
                "old_value": form.get("old_value", "").strip(),
                "new_value": form.get("new_value", "").strip(),
                "dev_date": form.get("dev_date", ""),
                "sit_date": form.get("sit_date", ""),
                "uat_date": form.get("uat_date", ""),
                "preprod_date": form.get("preprod_date", ""),
                "mig_date": form.get("mig_date", ""),
                "prod_date": form.get("prod_date", ""),
                "release_id": request.form.get("release_id") or None,
                "created_by": session.get("username"),
                "updated_by": session.get("username"),
                "created_at": ts,
                "updated_at": ts,
            }
            change_id = create_change_record(payload)
            save_attachments(change_id)
            log_audit("create", "change", change_id, f"Created {jira_ref}")
            flash("Change added successfully.", "success")
            if form.get("save_mode") == "save_add_another":
                return redirect(url_for("changes_page", entry_saved="1"))
            return redirect(url_for("view_change", change_id=change_id))

        if action in {"preview_import", "commit_import"}:
            if not can_edit():
                flash("Your role is read-only.", "warning")
                return redirect(url_for("changes_page"))

            preview_id = request.form.get("preview_id", "").strip()
            preview = load_import_preview(preview_id) if preview_id else None
            if action == "preview_import" and not preview:
                file = request.files.get("jira_file")
                if not file or not file.filename:
                    flash("Choose a JIRA CSV export to preview.", "warning")
                    return redirect(url_for("changes_page"))
                if not file.filename.lower().endswith(".csv"):
                    flash("Please upload a CSV export from JIRA.", "warning")
                    return redirect(url_for("changes_page"))
                preview_id = create_import_preview(file)
                preview = load_import_preview(preview_id)
                if preview is None:
                    flash("The import preview could not be created.", "danger")
                    return redirect(url_for("changes_page"))
                preview["preview_id"] = preview_id
            elif preview:
                preview["preview_id"] = preview_id

            if not preview:
                flash("The saved preview could not be found. Please upload the file again.", "warning")
                return redirect(url_for("changes_page"))

            preview_context = build_import_preview(preview, request.form)

            if action == "preview_import":
                selected_mapping = {field: request.form.get(f"map_{field}", preview_context["mapping"].get(field, "")) for field in ("jira_ref", "title", "description")}
                save_setting("jira_import_mapping", selected_mapping)
                if preview_context["row_count"] == 0:
                    flash("The CSV loaded, but no data rows were found.", "warning")
                else:
                    flash("Preview created. Review the rows below before importing.", "success")
            else:
                strategy = request.form.get("duplicate_strategy", "skip")
                selected_mapping = {field: request.form.get(f"map_{field}", preview_context["mapping"].get(field, "")) for field in ("jira_ref", "title", "description")}
                save_setting("jira_import_mapping", selected_mapping)
                row_count = int(request.form.get("row_count", preview_context["row_count"]))
                imported_count = skipped_count = updated_count = merge_count = 0
                first_change_id = None

                for idx in range(row_count):
                    if request.form.get(f"include_{idx}") != "1":
                        skipped_count += 1
                        continue
                    jira_ref = request.form.get(f"row_{idx}_jira_ref", "").strip()
                    title = request.form.get(f"row_{idx}_title", "").strip()
                    description = request.form.get(f"row_{idx}_description", "").strip()
                    if not jira_ref:
                        skipped_count += 1
                        continue
                    selected_environment = request.form.get(f"row_{idx}_selected_environment", "").strip()
                    system_name = request.form.get(f"row_{idx}_system_name", "").strip()
                    status = request.form.get(f"row_{idx}_status", "").strip()
                    region_raw = request.form.get(f"row_{idx}_region", "").strip()
                    region_display, region_iso3 = normalize_region(region_raw)
                    deployed_by = request.form.get(f"row_{idx}_deployed_by", session.get("username", "")).strip() or session.get("username", "")
                    ts = now_iso()
                    payload = {
                        "jira_ref": jira_ref,
                        "title": title,
                        "selected_environment": selected_environment,
                        "system_name": system_name,
                        "change_type": "",
                        "status": status,
                        "version": "",
                        "region": region_display,
                        "region_iso3": region_iso3,
                        "deployed_by": deployed_by,
                        "description": description,
                        "old_value": "",
                        "new_value": "",
                        "dev_date": "",
                        "sit_date": "",
                        "uat_date": "",
                        "preprod_date": "",
                        "mig_date": "",
                        "prod_date": "",
                        "release_id": request.form.get(f"row_{idx}_release_id") or None,
                        "created_by": session.get("username"),
                        "updated_by": session.get("username"),
                        "created_at": ts,
                        "updated_at": ts,
                    }
                    existing = db.execute("SELECT * FROM changes WHERE jira_ref=?", (jira_ref,)).fetchone()
                    if existing:
                        if strategy == "skip":
                            skipped_count += 1
                            continue
                        if strategy == "overwrite":
                            payload["created_by"] = existing["created_by"] or existing["updated_by"] or session.get("username")
                            payload["created_at"] = existing["created_at"] or ts
                            update_change_record(existing["id"], payload)
                            updated_count += 1
                            log_audit("update", "change", existing["id"], f"Import overwrite for {jira_ref}")
                            continue
                        merged = dict(existing)
                        for field in ["title", "selected_environment", "system_name", "status", "region", "region_iso3", "deployed_by", "description"]:
                            incoming = payload.get(field, "")
                            existing_value = (existing[field] or "") if field in existing.keys() else ""
                            if incoming and not str(existing_value).strip():
                                merged[field] = incoming
                        merged["jira_ref"] = jira_ref
                        merged["updated_by"] = session.get("username")
                        merged["updated_at"] = ts
                        update_change_record(existing["id"], merged)
                        merge_count += 1
                        log_audit("update", "change", existing["id"], f"Import merge for {jira_ref}")
                        continue

                    change_id = create_change_record(payload)
                    if first_change_id is None:
                        first_change_id = change_id
                    imported_count += 1
                    log_audit("create", "change", change_id, f"Imported {jira_ref} from CSV")

                db.execute(
                    "INSERT INTO import_history(username, file_name, total_rows, imported_count, skipped_count, updated_count, merge_count, strategy, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (session.get("username"), preview_context["file_name"], row_count, imported_count, skipped_count, updated_count, merge_count, strategy, now_iso()),
                )
                db.commit()
                log_audit("import", "changes", None, f"Imported file {preview_context['file_name']} ({imported_count} new, {updated_count} overwritten, {merge_count} merged, {skipped_count} skipped)")
                try:
                    (PREVIEW_DIR / f"{preview_id}.json").unlink(missing_ok=True)
                except Exception:
                    pass
                flash(f"Import complete. {imported_count} added, {updated_count} overwritten, {merge_count} merged, {skipped_count} skipped.", "success")
                if first_change_id:
                    return redirect(url_for("view_change", change_id=first_change_id))
                return redirect(url_for("changes_page"))

    filters = {
        "region": request.args.get("region", ""),
        "environment": request.args.get("environment", ""),
        "system": request.args.get("system", ""),
        "status": request.args.get("status", ""),
        "release_id": request.args.get("release_id", ""),
        "keyword": request.args.get("keyword", ""),
    }
    page, page_size = pagination_from_request(request.args)
    where_sql, params = build_filter_conditions(filters, alias="c", release_alias="r")
    total_items = db.execute(
        f"SELECT COUNT(*) AS c FROM changes c LEFT JOIN releases r ON r.id = c.release_id WHERE {where_sql}",
        params,
    ).fetchone()["c"]
    pagination = build_pagination("changes_page", page, page_size, total_items, filters)
    changes = db.execute(
        f"""
        SELECT c.*, r.name AS release_name
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql}
        ORDER BY c.updated_at DESC
        LIMIT ? OFFSET ?
        """,
        [*params, pagination["page_size"], (pagination["page"] - 1) * pagination["page_size"]],
    ).fetchall()
    attachment_count_map: dict[int, int] = {}
    if changes:
        placeholders = ",".join(["?"] * len(changes))
        counts = db.execute(
            f"SELECT change_id, COUNT(*) c FROM attachments WHERE change_id IN ({placeholders}) GROUP BY change_id",
            [change["id"] for change in changes],
        ).fetchall()
        attachment_count_map = {r["change_id"]: r["c"] for r in counts}

    return render_template(
        "changes.html",
        settings=settings,
        changes=changes,
        filters=filters,
        filter_chips=build_filter_chips(filters, settings, include_release=True),
        clear_filters_url=url_for("changes_page"),
        attachment_count_map=attachment_count_map,
        today=today_iso(),
        preview_context=preview_context,
        import_history=get_import_history(8),
        saved_import_mapping=fetch_setting("jira_import_mapping", {"jira_ref": "", "title": "", "description": ""}),
        releases=get_release_options(),
        pagination=pagination,
        page_size_options=PAGE_SIZE_OPTIONS,
        entry_saved=request.args.get("entry_saved") == "1",
    )


def save_attachments(change_id: int) -> None:
    db = get_db()
    files = request.files.getlist("attachments")
    for file in files:
        if not file or not file.filename:
            continue
        if not allowed_file(file.filename):
            continue
        original_name = secure_filename(file.filename)
        stored_name = f"{uuid4().hex}_{original_name}"
        target = UPLOAD_DIR / stored_name
        file.save(target)
        db.execute(
            "INSERT INTO attachments(change_id, original_name, stored_name, uploaded_at) VALUES (?, ?, ?, ?)",
            (change_id, original_name, stored_name, now_iso()),
        )
    db.commit()


@app.route("/change/<int:change_id>", methods=["GET", "POST"])
@login_required
def view_change(change_id: int):
    db = get_db()
    settings = get_context_settings()
    change = db.execute("SELECT c.*, r.name AS release_name FROM changes c LEFT JOIN releases r ON r.id = c.release_id WHERE c.id=?", (change_id,)).fetchone()
    if not change:
        flash("Change not found.", "danger")
        return redirect(url_for("changes_page"))

    if request.method == "POST":
        if not can_edit():
            flash("Your role is read-only.", "warning")
            return redirect(url_for("view_change", change_id=change_id))
        region_display, region_iso3 = normalize_region(request.form.get("region", ""))
        payload = {
            "id": change_id,
            "jira_ref": request.form.get("jira_ref", "").strip(),
            "title": request.form.get("title", "").strip(),
            "selected_environment": request.form.get("selected_environment", ""),
            "system_name": request.form.get("system_name", ""),
            "change_type": request.form.get("change_type", ""),
            "status": request.form.get("status", ""),
            "version": request.form.get("version", "").strip(),
            "region": region_display,
            "region_iso3": region_iso3,
            "deployed_by": request.form.get("deployed_by", ""),
            "description": request.form.get("description", "").strip(),
            "old_value": request.form.get("old_value", "").strip(),
            "new_value": request.form.get("new_value", "").strip(),
            "dev_date": request.form.get("dev_date", ""),
            "sit_date": request.form.get("sit_date", ""),
            "uat_date": request.form.get("uat_date", ""),
            "preprod_date": request.form.get("preprod_date", ""),
            "mig_date": request.form.get("mig_date", ""),
            "prod_date": request.form.get("prod_date", ""),
            "release_id": request.form.get("release_id") or None,
            "updated_by": session.get("username"),
            "updated_at": now_iso(),
        }
        if not payload["jira_ref"]:
            flash("JIRA reference is required.", "danger")
            return redirect(url_for("view_change", change_id=change_id))
        update_change_record(change_id, payload)
        save_attachments(change_id)
        log_audit("update", "change", change_id, f"Updated {payload['jira_ref']}")
        flash("Change updated successfully.", "success")
        return redirect(url_for("view_change", change_id=change_id))

    attachments = db.execute("SELECT * FROM attachments WHERE change_id=? ORDER BY uploaded_at DESC", (change_id,)).fetchall()
    history = db.execute("SELECT * FROM audit_log WHERE entity_type='change' AND entity_id=? ORDER BY created_at DESC", (change_id,)).fetchall()
    timeline = [
        {"label": "DEV", "date": change["dev_date"]},
        {"label": "SIT", "date": change["sit_date"]},
        {"label": "UAT", "date": change["uat_date"]},
        {"label": "PREPROD", "date": change["preprod_date"]},
        {"label": "MIG", "date": change["mig_date"]},
        {"label": "PROD", "date": change["prod_date"]},
    ]
    return render_template("view_change.html", change=change, attachments=attachments, history=history, settings=settings, today=today_iso(), timeline=timeline, releases=get_release_options())


@app.post("/change/<int:change_id>/delete")
@login_required
@edit_required
def delete_change(change_id: int):
    db = get_db()
    row = db.execute("SELECT jira_ref FROM changes WHERE id=?", (change_id,)).fetchone()
    if row:
        attachments = db.execute("SELECT stored_name FROM attachments WHERE change_id=?", (change_id,)).fetchall()
        for attachment in attachments:
            p = UPLOAD_DIR / attachment["stored_name"]
            if p.exists():
                p.unlink()
        db.execute("DELETE FROM changes WHERE id=?", (change_id,))
        db.commit()
        log_audit("delete", "change", change_id, f"Deleted {row['jira_ref']}")
        flash("Change deleted.", "info")
    return redirect(url_for("changes_page"))


@app.post("/attachment/<int:attachment_id>/delete")
@login_required
@edit_required
def delete_attachment(attachment_id: int):
    db = get_db()
    row = db.execute("SELECT * FROM attachments WHERE id=?", (attachment_id,)).fetchone()
    if row:
        p = UPLOAD_DIR / row["stored_name"]
        if p.exists():
            p.unlink()
        db.execute("DELETE FROM attachments WHERE id=?", (attachment_id,))
        db.commit()
        log_audit("delete", "attachment", attachment_id, f"Removed {row['original_name']}")
        flash("Attachment removed.", "info")
        return redirect(url_for("view_change", change_id=row["change_id"]))
    flash("Attachment not found.", "warning")
    return redirect(url_for("changes_page"))


@app.route("/compare")
@login_required
def compare_envs():
    db = get_db()
    settings = get_context_settings()
    compare_env = request.args.get("compare_env", "SIT")
    filters = {
        "region": request.args.get("region", ""),
        "system": request.args.get("system", ""),
        "status": request.args.get("status", ""),
        "release_id": request.args.get("release_id", ""),
        "keyword": (request.args.get("keyword") or request.args.get("search") or "").strip(),
    }
    page, page_size = pagination_from_request(request.args)
    compare_col = ENV_COLUMNS.get(compare_env, "sit_date")
    where_sql, params = build_filter_conditions(filters, alias="c", release_alias="r")
    where = [where_sql, f"(c.{compare_col} IS NOT NULL AND c.{compare_col} != '')", "(c.prod_date IS NULL OR c.prod_date = '')"]
    total_items = db.execute(
        f"SELECT COUNT(*) AS c FROM changes c LEFT JOIN releases r ON r.id = c.release_id WHERE {' AND '.join(where)}",
        params,
    ).fetchone()["c"]
    pagination = build_pagination(
        "compare_envs",
        page,
        page_size,
        total_items,
        {"compare_env": compare_env, **filters},
    )
    missing = db.execute(
        f"""
        SELECT c.*, r.name AS release_name
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {' AND '.join(where)}
        ORDER BY c.updated_at DESC
        LIMIT ? OFFSET ?
        """,
        [*params, pagination["page_size"], (pagination["page"] - 1) * pagination["page_size"]],
    ).fetchall()
    coverage = db.execute(
        f"""
        SELECT
            SUM(CASE WHEN c.dev_date IS NOT NULL AND c.dev_date != '' THEN 1 ELSE 0 END) AS dev_count,
            SUM(CASE WHEN c.sit_date IS NOT NULL AND c.sit_date != '' THEN 1 ELSE 0 END) AS sit_count,
            SUM(CASE WHEN c.uat_date IS NOT NULL AND c.uat_date != '' THEN 1 ELSE 0 END) AS uat_count,
            SUM(CASE WHEN c.preprod_date IS NOT NULL AND c.preprod_date != '' THEN 1 ELSE 0 END) AS preprod_count,
            SUM(CASE WHEN c.mig_date IS NOT NULL AND c.mig_date != '' THEN 1 ELSE 0 END) AS mig_count,
            SUM(CASE WHEN c.prod_date IS NOT NULL AND c.prod_date != '' THEN 1 ELSE 0 END) AS prod_count
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql}
        """,
        params,
    ).fetchone()
    summary = db.execute(
        f"""
        SELECT
            COUNT(*) AS total_missing,
            SUM(CASE WHEN c.status IN ('Failed', 'Rolled Back') THEN 1 ELSE 0 END) AS blockers,
            SUM(CASE WHEN c.release_id IS NOT NULL THEN 1 ELSE 0 END) AS linked_releases,
            SUM(CASE WHEN datetime(c.updated_at) >= datetime('now', '-7 day') THEN 1 ELSE 0 END) AS updated_week
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {' AND '.join(where)}
        """,
        params,
    ).fetchone()
    changes_link = url_for("changes_page", **{k: v for k, v in filters.items() if v})
    return render_template(
        "compare.html",
        compare_env=compare_env,
        missing_in_prod=missing,
        coverage=coverage,
        summary=summary,
        filters=filters,
        changes_link=changes_link,
        settings=settings,
        filter_chips=build_filter_chips(filters, settings, include_release=True, extra=[("Comparison", compare_env)]),
        clear_filters_url=url_for("compare_envs", compare_env=compare_env),
        releases=get_release_options(),
        pagination=pagination,
        page_size_options=PAGE_SIZE_OPTIONS,
    )


@app.route("/settings", methods=["GET", "POST"])
@login_required
@admin_required
def settings_page():
    db = get_db()
    settings = get_context_settings()

    if request.method == "POST":
        action = request.form.get("action", "settings")
        if action == "settings":
            save_setting("current_theme", request.form.get("current_theme", DEFAULT_OPTIONS["current_theme"]))
            save_setting("environments", parse_multiline_list(request.form.get("environments", "")))
            save_setting("systems", parse_multiline_list(request.form.get("systems", "")))
            save_setting("change_types", parse_multiline_list(request.form.get("change_types", "")))
            save_setting("statuses", parse_multiline_list(request.form.get("statuses", "")))
            regions = parse_regions(request.form.get("regions", ""))
            if regions:
                save_setting("regions", regions)
            save_setting("plugins", {name: request.form.get(f"plugin_{name}") == "on" for name in DEFAULT_PLUGINS})
            log_audit("update", "settings", None, "Updated app settings")
            flash("Settings updated.", "success")
            return redirect(url_for("settings_page"))
        if action == "add_user":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            role = request.form.get("role", "user")
            if role not in USER_ROLES:
                role = "user"
            if not username or not password:
                flash("Username and password are required.", "danger")
            else:
                try:
                    db.execute(
                        "INSERT INTO users(username, password_hash, role, created_at) VALUES (?, ?, ?, ?)",
                        (username, generate_password_hash(password), role, now_iso()),
                    )
                    db.commit()
                    log_audit("create", "user", None, f"Created user {username}")
                    flash("User added.", "success")
                except sqlite3.IntegrityError:
                    flash("That username already exists.", "warning")
            return redirect(url_for("settings_page"))
        if action == "set_user_status":
            user_id = coerce_int(request.form.get("user_id"), 0, minimum=0)
            enabled = request.form.get("enabled") == "1"
            user = db.execute(
                "SELECT id, username, role, is_active FROM users WHERE id=?",
                (user_id,),
            ).fetchone()
            if not user:
                flash("User not found.", "warning")
            elif not enabled and user["id"] == session.get("user_id"):
                flash("You cannot disable the account you are currently using.", "warning")
            elif not enabled and user["role"] == "admin" and active_admin_count() <= 1:
                flash("You must keep at least one active admin account.", "warning")
            else:
                db.execute("UPDATE users SET is_active=? WHERE id=?", (1 if enabled else 0, user_id))
                db.commit()
                log_audit(
                    "update",
                    "user",
                    user_id,
                    f"{'Enabled' if enabled else 'Disabled'} user {user['username']}",
                )
                flash(
                    f"User {user['username']} {'enabled' if enabled else 'disabled'}.",
                    "success",
                )
            return redirect(url_for("settings_page"))
        if action == "reset_password":
            user_id = coerce_int(request.form.get("user_id"), 0, minimum=0)
            new_password = request.form.get("new_password", "")
            user = db.execute("SELECT id, username FROM users WHERE id=?", (user_id,)).fetchone()
            if not user:
                flash("User not found.", "warning")
            elif len(new_password) < 8:
                flash("New passwords must be at least 8 characters long.", "warning")
            else:
                db.execute(
                    "UPDATE users SET password_hash=? WHERE id=?",
                    (generate_password_hash(new_password), user_id),
                )
                db.commit()
                log_audit("update", "user", user_id, f"Reset password for {user['username']}")
                flash(f"Password reset for {user['username']}.", "success")
            return redirect(url_for("settings_page"))

    textarea_values = {
        "environments": "\n".join(settings["environments"]),
        "systems": "\n".join(settings["systems"]),
        "change_types": "\n".join(settings["change_types"]),
        "statuses": "\n".join(settings["statuses"]),
        "regions": serialize_regions_for_textarea(settings["regions"]),
    }
    users = db.execute("SELECT id, username, role, is_active, created_at FROM users ORDER BY username").fetchall()
    return render_template(
        "settings.html",
        settings=settings,
        textarea_values=textarea_values,
        users=users,
        user_roles=USER_ROLES,
        plugins=get_plugins(),
        security=security_summary(),
    )


@app.route("/jira-sync", methods=["GET", "POST"])
@login_required
def jira_sync_page():
    if not plugin_enabled("jira_sync"):
        abort(404)
    if request.method == "POST":
        if not can_edit():
            flash("Your role is read-only.", "warning")
            return redirect(url_for("jira_sync_page"))
        action = request.form.get("action", "save_config")
        if action == "save_config":
            cfg = get_jira_config()
            cfg.update({
                "enabled": request.form.get("enabled") == "on",
                "base_url": request.form.get("base_url", "").strip(),
                "email": request.form.get("email", "").strip(),
                "api_token": request.form.get("api_token", "").strip() or cfg.get("api_token", ""),
                "project_key": request.form.get("project_key", "").strip(),
                "jql": request.form.get("jql", "").strip(),
                "max_results": coerce_int(request.form.get("max_results"), 100, minimum=1, maximum=500),
                "schedule_enabled": request.form.get("schedule_enabled") == "on",
                "schedule_time": request.form.get("schedule_time", "09:00").strip() or "09:00",
                "sync_strategy": request.form.get("sync_strategy", "merge"),
            })
            save_setting("jira_api", cfg)
            flash("JIRA sync settings saved.", "success")
            return redirect(url_for("jira_sync_page"))
        if action == "test_connection":
            try:
                cfg = get_jira_config()
                resp = requests.get(cfg["base_url"].rstrip("/") + "/rest/api/3/myself", auth=(cfg["email"], cfg["api_token"]), headers={"Accept": "application/json"}, timeout=20)
                resp.raise_for_status()
                who = resp.json().get("displayName") or resp.json().get("emailAddress") or "JIRA user"
                flash(f"Connection successful: {who}", "success")
            except Exception as exc:
                flash(f"Connection failed: {exc}", "danger")
            return redirect(url_for("jira_sync_page"))
        if action == "sync_now":
            try:
                result = perform_jira_sync(session.get("username"), "manual")
                flash(f"Sync complete. {result['imported']} added, {result['updated']} overwritten, {result['merged']} merged, {result['skipped']} skipped.", "success")
                if result.get("first_change_id"):
                    return redirect(url_for("view_change", change_id=result["first_change_id"]))
            except Exception as exc:
                flash(f"JIRA sync failed: {exc}", "danger")
            return redirect(url_for("jira_sync_page"))
    db = get_db()
    history = db.execute("SELECT * FROM sync_history ORDER BY created_at DESC LIMIT 25").fetchall()
    cfg = get_jira_config()
    next_run = cfg.get("schedule_time", "09:00") if cfg.get("schedule_enabled") else "Disabled"
    return render_template("jira_sync.html", jira_config=cfg, sync_history=history, next_run=next_run)


@app.route("/releases", methods=["GET", "POST"])
@login_required
def releases_page():
    if not plugin_enabled("releases"):
        abort(404)
    db = get_db()
    if request.method == "POST":
        if not can_edit():
            flash("Your role is read-only.", "warning")
            return redirect(url_for("releases_page"))
        name = request.form.get("name", "").strip()
        if not name:
            flash("Release name is required.", "warning")
            return redirect(url_for("releases_page"))
        try:
            db.execute("INSERT INTO releases(name, description, release_date, created_by, created_at) VALUES (?, ?, ?, ?, ?)", (name, request.form.get("description", "").strip(), request.form.get("release_date", "").strip(), session.get("username"), now_iso()))
            db.commit()
            flash("Release created.", "success")
        except sqlite3.IntegrityError:
            flash("That release name already exists.", "warning")
        return redirect(url_for("releases_page"))
    settings = get_context_settings()
    filters = {
        "time_range": request.args.get("time_range", "30d") if request.args.get("time_range") else "",
        "start_date": request.args.get("start_date", ""),
        "end_date": request.args.get("end_date", ""),
        "region": request.args.get("region", ""),
        "system": request.args.get("system", ""),
        "status": request.args.get("status", ""),
        "keyword": request.args.get("keyword", "").strip(),
    }
    releases = fetch_release_rollup(filters)
    summary = {
        "release_count": len(releases),
        "linked_changes": sum(item["change_count"] or 0 for item in releases),
        "releases_with_pending": sum(1 for item in releases if (item["pending_count"] or 0) > 0),
        "blocked_releases": sum(1 for item in releases if (item["blocked_count"] or 0) > 0),
    }
    return render_template(
        "releases.html",
        releases=releases,
        summary=summary,
        settings=settings,
        filters=filters,
        filter_chips=build_filter_chips(filters, settings, include_time=has_time_scope(filters)),
        clear_filters_url=url_for("releases_page"),
    )


@app.route("/activity-audit")
@login_required
def activity_audit_page():
    return redirect(url_for("audit_page", **request.args))


@app.route("/audit")
@login_required
def audit_page():
    keyword = request.args.get("keyword", "").strip()
    page, page_size = pagination_from_request(request.args, default_page_size=50)
    total_items, _ = fetch_audit_results(keyword, page=1, page_size=1)
    pagination = build_pagination(
        "audit_page",
        page,
        page_size,
        total_items,
        {"keyword": keyword},
    )
    _, logs = fetch_audit_results(keyword, page=pagination["page"], page_size=pagination["page_size"])
    return render_template(
        "audit.html",
        logs=logs,
        filters={"keyword": keyword},
        filter_chips=build_filter_chips({"keyword": keyword}, get_context_settings()),
        clear_filters_url=url_for("audit_page"),
        pagination=pagination,
        page_size_options=PAGE_SIZE_OPTIONS,
    )


@app.route("/export/changes.xlsx")
@login_required
def export_changes():
    from openpyxl import Workbook

    db = get_db()
    where_sql, params = build_filter_conditions(request.args, alias="c", release_alias="r")
    rows = db.execute(
        f"""
        SELECT c.*, r.name AS release_name
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql}
        ORDER BY c.updated_at DESC
        """,
        params,
    ).fetchall()

    wb = Workbook()
    ws = wb.active
    ws.title = "Changes"
    headers = [
        "ID", "JIRA Reference", "Title", "Release", "Environment", "System", "Change Type", "Status", "Version",
        "Region", "Region ISO3", "Deployed By", "Description", "Old Value", "New Value",
        "DEV", "SIT", "UAT", "PREPROD", "MIG", "PROD", "Created By", "Updated By", "Created At", "Updated At"
    ]
    ws.append(headers)
    for row in rows:
        ws.append([
            row["id"], row["jira_ref"], row["title"], row["release_name"], row["selected_environment"], row["system_name"], row["change_type"],
            row["status"], row["version"], row["region"], row["region_iso3"], row["deployed_by"], row["description"],
            row["old_value"], row["new_value"], row["dev_date"], row["sit_date"], row["uat_date"], row["preprod_date"],
            row["mig_date"], row["prod_date"], row["created_by"], row["updated_by"], row["created_at"], row["updated_at"]
        ])
    export_dir = BASE_DIR / "exports"
    export_dir.mkdir(exist_ok=True)
    filename = f"jira_change_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    path = export_dir / filename
    wb.save(path)
    log_audit("export", "changes", None, f"Exported {len(rows)} rows to Excel")
    return send_from_directory(export_dir, filename, as_attachment=True, download_name=filename)


@app.route("/export/changes.csv")
@login_required
def export_changes_csv():
    db = get_db()
    where_sql, params = build_filter_conditions(request.args, alias="c", release_alias="r")
    rows = db.execute(
        f"""
        SELECT c.*, r.name AS release_name
        FROM changes c
        LEFT JOIN releases r ON r.id = c.release_id
        WHERE {where_sql}
        ORDER BY c.updated_at DESC
        """,
        params,
    ).fetchall()
    output = io.StringIO()
    writer = csv.writer(output)
    headers = [
        "ID", "JIRA Reference", "Title", "Release", "Environment", "System", "Change Type", "Status", "Version",
        "Region", "Region ISO3", "Deployed By", "Description", "Old Value", "New Value",
        "DEV", "SIT", "UAT", "PREPROD", "MIG", "PROD", "Created By", "Updated By", "Created At", "Updated At"
    ]
    writer.writerow(headers)
    for row in rows:
        writer.writerow([
            row["id"], row["jira_ref"], row["title"], row["release_name"], row["selected_environment"], row["system_name"], row["change_type"],
            row["status"], row["version"], row["region"], row["region_iso3"], row["deployed_by"], row["description"],
            row["old_value"], row["new_value"], row["dev_date"], row["sit_date"], row["uat_date"], row["preprod_date"],
            row["mig_date"], row["prod_date"], row["created_by"], row["updated_by"], row["created_at"], row["updated_at"]
        ])
    response = make_response(output.getvalue())
    response.headers["Content-Type"] = "text/csv; charset=utf-8"
    response.headers["Content-Disposition"] = f"attachment; filename=jira_change_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    log_audit("export", "changes", None, f"Exported {len(rows)} rows to CSV")
    return response


@app.route("/attachment/<int:attachment_id>/download")
@login_required
def download_attachment(attachment_id: int):
    db = get_db()
    row = db.execute("SELECT * FROM attachments WHERE id=?", (attachment_id,)).fetchone()
    if not row:
        flash("Attachment not found.", "danger")
        return redirect(url_for("changes_page"))
    return send_from_directory(
        app.config["UPLOAD_FOLDER"], row["stored_name"], as_attachment=True, download_name=row["original_name"]
    )


@app.route("/uploads/<path:filename>")
@login_required
def uploaded_file(filename: str):
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename, as_attachment=False)


if __name__ == "__main__":
    init_db()
    app.run(debug=True, host="127.0.0.1", port=5000)
