from __future__ import annotations

import re
from collections import defaultdict
from datetime import date, datetime, timedelta
from typing import Any


TIME_GROUPING_OPTIONS = ["auto", "daily", "weekly", "monthly"]

STATUS_PATTERNS = [
    ("ready for prod", "Ready for PROD"),
    ("rolled back", "Rolled Back"),
    ("rollback", "Rolled Back"),
    ("in progress", "In Progress"),
    ("deployed", "Deployed"),
    ("failed", "Failed"),
    ("planned", "Planned"),
]

STOPWORDS = {
    "show",
    "what",
    "which",
    "find",
    "list",
    "give",
    "me",
    "the",
    "a",
    "an",
    "all",
    "any",
    "for",
    "in",
    "on",
    "of",
    "to",
    "from",
    "this",
    "that",
    "these",
    "those",
    "with",
    "related",
    "changes",
    "change",
    "items",
    "item",
    "records",
    "record",
    "related",
    "linked",
    "jira",
    "reference",
    "references",
    "analytics",
    "audit",
    "activity",
    "compare",
    "comparison",
    "release",
    "releases",
    "prod",
    "dev",
    "sit",
    "uat",
    "preprod",
    "mig",
    "environment",
    "environments",
    "weekly",
    "monthly",
    "daily",
    "auto",
}


def _term_list(value: str) -> list[str]:
    cleaned = re.sub(r"[^a-zA-Z0-9\- ]+", " ", value or "")
    return [term for term in cleaned.split() if term]


def _qualified(alias: str | None, column: str) -> str:
    return f"{alias}.{column}" if alias else column


def build_change_where(
    filters: dict[str, Any] | Any,
    *,
    alias: str | None = None,
    release_alias: str | None = None,
    include_region: bool = True,
    date_column: str | None = None,
) -> tuple[str, list[Any]]:
    region_filter = (filters.get("region") or "").strip()
    environment = (filters.get("environment") or "").strip()
    system_name = (filters.get("system") or "").strip()
    status = (filters.get("status") or "").strip()
    keyword = (filters.get("keyword") or "").strip()
    release_id = filters.get("release_id")
    missing_prod = bool(filters.get("missing_prod"))
    require_release = bool(filters.get("require_release"))

    where = ["1=1"]
    params: list[Any] = []

    if include_region and region_filter and region_filter != "All":
        where.append(f"({_qualified(alias, 'region')} = ? OR {_qualified(alias, 'region_iso3')} = ?)")
        params.extend([region_filter, region_filter])
    if environment and environment != "All":
        where.append(f"{_qualified(alias, 'selected_environment')} = ?")
        params.append(environment)
    if system_name and system_name != "All":
        where.append(f"{_qualified(alias, 'system_name')} = ?")
        params.append(system_name)
    if status and status != "All":
        where.append(f"{_qualified(alias, 'status')} = ?")
        params.append(status)
    if release_id:
        where.append(f"{_qualified(alias, 'release_id')} = ?")
        params.append(int(release_id))
    if require_release:
        where.append(f"{_qualified(alias, 'release_id')} IS NOT NULL")
    if missing_prod:
        where.append(
            f"({_qualified(alias, 'prod_date')} IS NULL OR {_qualified(alias, 'prod_date')} = '')"
        )
        where.append(
            "("
            + " OR ".join(
                f"{_qualified(alias, column)} IS NOT NULL AND {_qualified(alias, column)} != ''"
                for column in ["dev_date", "sit_date", "uat_date", "preprod_date", "mig_date"]
            )
            + ")"
        )

    if keyword:
        search_fields = [
            _qualified(alias, "jira_ref"),
            _qualified(alias, "title"),
            _qualified(alias, "description"),
            _qualified(alias, "old_value"),
            _qualified(alias, "new_value"),
            _qualified(alias, "version"),
            _qualified(alias, "deployed_by"),
            _qualified(alias, "region"),
            _qualified(alias, "system_name"),
            _qualified(alias, "selected_environment"),
        ]
        if release_alias:
            search_fields.append(f"{release_alias}.name")
            search_fields.append(f"{release_alias}.description")
        for term in _term_list(keyword):
            like = f"%{term}%"
            where.append("(" + " OR ".join(f"{field} LIKE ?" for field in search_fields) + ")")
            params.extend([like] * len(search_fields))

    if date_column:
        date_expr = date_column if "." in date_column else _qualified(alias, date_column)
        start_date = (filters.get("start_date") or "").strip()
        end_date = (filters.get("end_date") or "").strip()
        if start_date:
            where.append(f"date({date_expr}) >= date(?)")
            params.append(start_date)
        if end_date:
            where.append(f"date({date_expr}) <= date(?)")
            params.append(end_date)

    return " AND ".join(where), params


def resolve_chart_grouping(filters: dict[str, Any], start_date: str, end_date: str) -> dict[str, Any]:
    requested = (filters.get("grouping_mode") or "auto").strip().lower()
    if requested not in TIME_GROUPING_OPTIONS:
        requested = "auto"

    try:
        start = datetime.strptime(start_date, "%Y-%m-%d").date()
        end = datetime.strptime(end_date, "%Y-%m-%d").date()
    except Exception:
        start = end = date.today()

    span_days = max(1, (end - start).days + 1)
    if requested == "auto":
        if span_days <= 14:
            mode = "daily"
        elif span_days <= 60:
            mode = "weekly"
        else:
            mode = "monthly"
        label = f"{mode.capitalize()} (auto)"
    else:
        mode = requested
        label = mode.capitalize()

    subtitle = {
        "daily": "Grouped by day for the selected range.",
        "weekly": "Grouped by week for readability across broader time windows.",
        "monthly": "Grouped by month to keep long-range trends readable.",
    }[mode]
    return {"requested": requested, "mode": mode, "label": label, "subtitle": subtitle, "span_days": span_days}


def bucket_time_series(rows: list[dict[str, Any]], grouping: dict[str, Any], value_keys: list[str]) -> list[dict[str, Any]]:
    buckets: dict[str, dict[str, Any]] = {}
    for row in rows:
        row_date = row.get("label") or row.get("date")
        if not row_date:
            continue
        try:
            current = datetime.strptime(str(row_date), "%Y-%m-%d").date()
        except Exception:
            continue
        if grouping["mode"] == "daily":
            key = current.isoformat()
            display = current.strftime("%d %b")
            sort_key = key
        elif grouping["mode"] == "weekly":
            monday = current - timedelta(days=current.weekday())
            key = monday.isoformat()
            display = f"Week of {monday.strftime('%d %b')}"
            sort_key = key
        else:
            month_start = current.replace(day=1)
            key = month_start.isoformat()
            display = month_start.strftime("%b %Y")
            sort_key = key
        bucket = buckets.setdefault(key, {"label": display, "_sort": sort_key, **{name: 0 for name in value_keys}})
        for name in value_keys:
            bucket[name] += int(row.get(name, 0) or 0)
    return [item for _, item in sorted(buckets.items(), key=lambda pair: pair[1]["_sort"])]


def parse_natural_language_query(query: str, settings: dict[str, Any]) -> dict[str, Any]:
    original = (query or "").strip()
    lowered = f" {original.lower()} "
    working = lowered

    filters: dict[str, Any] = {
        "region": "",
        "environment": "",
        "system": "",
        "status": "",
        "keyword": "",
        "release_id": "",
        "time_range": "",
        "start_date": "",
        "end_date": "",
        "grouping_mode": "auto",
    }
    parsed: dict[str, Any] = {
        "query": original,
        "intent": "changes",
        "compare_env": "SIT",
        "assistant_mode": False,
        "filters": filters,
        "used_phrases": [],
    }

    def consume(phrase: str) -> None:
        nonlocal working
        pattern = re.compile(rf"(?<!\w){re.escape(phrase.lower())}(?!\w)")
        if pattern.search(working):
            working = pattern.sub(" ", working)
            parsed["used_phrases"].append(phrase)

    if re.search(r"\b(compare|comparison|drift)\b", lowered) or re.search(r"\b(dev|sit|uat|preprod|mig)\s+and\s+prod\b", lowered):
        parsed["intent"] = "compare"
    elif re.search(r"\b(audit|activity|history|login|import|export)\b", lowered):
        parsed["intent"] = "audit"
    elif re.search(r"\b(release|releases|rollout)\b", lowered):
        parsed["intent"] = "releases"
    elif re.search(r"\b(analytics|trend|trends|chart|charts|volume|map)\b", lowered):
        parsed["intent"] = "analytics"

    if re.search(r"\b(show|what|which|find|list|compare)\b", lowered) or "?" in original:
        parsed["assistant_mode"] = True

    if re.search(r"\bmissing\s+prod\b|\bmissing\s+in\s+prod\b|\bnot\s+in\s+prod\b|\bwithout\s+prod\b", lowered):
        filters["missing_prod"] = True
        consume("missing prod")
        consume("missing in prod")
        consume("not in prod")
        consume("without prod")

    if "release item" in lowered or "release items" in lowered:
        filters["require_release"] = True
        consume("release item")
        consume("release items")

    today = date.today()
    time_match = re.search(r"\blast\s+(\d{1,3})\s+days?\b", lowered)
    if " today " in working:
        filters["time_range"] = "today"
        filters["start_date"] = today.isoformat()
        filters["end_date"] = today.isoformat()
        consume("today")
    elif " this week " in working:
        start = today - timedelta(days=today.weekday())
        filters["time_range"] = "custom"
        filters["start_date"] = start.isoformat()
        filters["end_date"] = today.isoformat()
        consume("this week")
    elif " last week " in working:
        end = today - timedelta(days=today.weekday() + 1)
        start = end - timedelta(days=6)
        filters["time_range"] = "custom"
        filters["start_date"] = start.isoformat()
        filters["end_date"] = end.isoformat()
        consume("last week")
    elif " last month " in working:
        first_this_month = today.replace(day=1)
        end = first_this_month - timedelta(days=1)
        start = end.replace(day=1)
        filters["time_range"] = "custom"
        filters["start_date"] = start.isoformat()
        filters["end_date"] = end.isoformat()
        consume("last month")
    elif " this month " in working:
        filters["time_range"] = "custom"
        filters["start_date"] = today.replace(day=1).isoformat()
        filters["end_date"] = today.isoformat()
        consume("this month")
    elif time_match:
        days = int(time_match.group(1))
        if days == 7:
            filters["time_range"] = "7d"
        elif days == 30:
            filters["time_range"] = "30d"
        elif days == 90:
            filters["time_range"] = "90d"
        else:
            start = today - timedelta(days=max(days - 1, 0))
            filters["time_range"] = "custom"
            filters["start_date"] = start.isoformat()
            filters["end_date"] = today.isoformat()
        consume(time_match.group(0).strip())

    for mode in TIME_GROUPING_OPTIONS[1:]:
        if re.search(rf"(?<!\w){re.escape(mode)}(?!\w)", working):
            filters["grouping_mode"] = mode
            consume(mode)
            break

    region_patterns: list[tuple[str, str]] = []
    for region in settings.get("regions", []):
        target = region.get("iso3") or region.get("name", "")
        for alias in [region.get("name", ""), *region.get("aliases", [])]:
            if alias:
                region_patterns.append((alias.lower(), target))
    for phrase, target in sorted(region_patterns, key=lambda item: len(item[0]), reverse=True):
        if re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", working):
            filters["region"] = target
            consume(phrase)
            break

    for system in sorted(settings.get("systems", []), key=len, reverse=True):
        if re.search(rf"(?<!\w){re.escape(system.lower())}(?!\w)", working):
            filters["system"] = system
            consume(system)
            break

    for phrase, canonical in STATUS_PATTERNS:
        if re.search(rf"(?<!\w){re.escape(phrase)}(?!\w)", working):
            filters["status"] = canonical
            consume(phrase)
            break

    env_hits: list[str] = []
    for environment in settings.get("environments", []):
        if re.search(rf"(?<!\w){re.escape(environment.lower())}(?!\w)", working):
            env_hits.append(environment)
            consume(environment)

    if parsed["intent"] == "compare":
        non_prod_envs = [item for item in env_hits if item != "PROD"]
        parsed["compare_env"] = non_prod_envs[0] if non_prod_envs else (env_hits[0] if env_hits else "SIT")
    elif env_hits:
        filters["environment"] = env_hits[0]

    jira_refs = re.findall(r"\b[A-Z][A-Z0-9]+-\d+\b", original)
    for jira_ref in jira_refs:
        consume(jira_ref.lower())

    residual = re.sub(r"[^a-z0-9\- ]+", " ", working.lower())
    keyword_terms = [
        term for term in residual.split()
        if term not in STOPWORDS and len(term) > 1
    ]
    if jira_refs:
        keyword_terms.extend(jira_refs)
    parsed["residual_text"] = " ".join(keyword_terms)
    if keyword_terms:
        filters["keyword"] = " ".join(dict.fromkeys(keyword_terms))

    return parsed
