(function () {
    const config = window.analyticsConfig || {};
    if (!config.analyticsUrl) {
        return;
    }

    const charts = {};
    let map;
    let geoLayer;
    let mapStats = {};

    function statusTone(status) {
        const value = (status || "").toLowerCase();
        if (["failed", "rolled back"].includes(value)) return "danger";
        if (["deployed"].includes(value)) return "success";
        if (["ready for prod", "planned", "in progress"].includes(value)) return "warning";
        return "info";
    }

    function badgeMarkup(label) {
        return `<span class="badge rounded-pill badge-soft badge-soft-${statusTone(label)}">${label || "Unspecified"}</span>`;
    }

    function chartPalette(count) {
        const base = ["#2563eb", "#0ea5e9", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#14b8a6", "#f97316"];
        return Array.from({ length: Math.max(count, 1) }, (_, index) => base[index % base.length]);
    }

    function axisTickOptions(labelCount, isTimeSeries = false) {
        const count = labelCount || 0;
        const rotate = count > 10;
        return {
            autoSkip: true,
            maxTicksLimit: isTimeSeries ? (count > 18 ? 8 : count > 10 ? 10 : 14) : (count > 16 ? 8 : 12),
            minRotation: rotate ? 32 : 0,
            maxRotation: rotate ? 32 : 0,
        };
    }

    function updateGroupingMeta(grouping) {
        const subtitle = document.getElementById("volumeChartSubtitle");
        const badge = document.getElementById("volumeChartModeBadge");
        const trendSubtitle = document.getElementById("successTrendSubtitle");
        const modeLabel = grouping?.label || "Auto";
        const summary = grouping?.subtitle || "Grouping updates automatically based on the selected date range.";
        if (subtitle) {
            subtitle.textContent = summary;
        }
        if (trendSubtitle) {
            trendSubtitle.textContent = `${summary} Exact values remain available in chart tooltips.`;
        }
        if (badge) {
            badge.textContent = modeLabel;
        }
    }

    function currentParams() {
        return new URLSearchParams(window.location.search);
    }

    function destroyChart(id) {
        if (charts[id]) {
            charts[id].destroy();
        }
    }

    function emptyStateMarkup(message, colspan) {
        return `<tr><td colspan="${colspan}" class="py-4"><div class="empty-inline">${message}</div></td></tr>`;
    }

    function setLoadingState(isLoading) {
        document.querySelectorAll("[data-loading-panel]").forEach((panel) => {
            panel.classList.toggle("is-loading", isLoading);
        });
        document.querySelectorAll("[data-summary-card]").forEach((panel) => {
            panel.classList.toggle("is-loading", isLoading);
        });
    }

    function setSummaryValue(key, value) {
        const card = document.querySelector(`[data-summary-card="${key}"] strong`);
        if (card) {
            card.textContent = value;
        }
    }

    function renderChart(canvasId, type, labels, data, datasetLabel, options = {}) {
        destroyChart(canvasId);
        const element = document.getElementById(canvasId);
        if (!element) return;
        const chartLabels = labels && labels.length ? labels : ["No data"];
        charts[canvasId] = new Chart(element, {
            type,
            data: {
                labels: chartLabels,
                datasets: [{
                    label: datasetLabel,
                    data: data && data.length ? data : [0],
                    backgroundColor: options.backgroundColor || chartPalette(labels ? labels.length : 1),
                    borderColor: options.borderColor || "#2563eb",
                    borderWidth: options.borderWidth || 1,
                    borderRadius: type === "bar" ? 10 : 0,
                    maxBarThickness: 42,
                    fill: options.fill || false,
                    tension: options.tension || 0.28,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                plugins: {
                    legend: { display: type !== "bar" },
                    tooltip: {
                        mode: "index",
                        intersect: false,
                        callbacks: {
                            label(context) {
                                const label = context.dataset.label ? `${context.dataset.label}: ` : "";
                                return `${label}${context.parsed.y ?? context.parsed}`;
                            },
                        },
                    },
                },
                scales: type === "pie" || type === "doughnut"
                    ? {}
                    : {
                        y: { beginAtZero: true, ticks: { precision: 0 } },
                        x: {
                            ticks: axisTickOptions(chartLabels.length, Boolean(options.isTimeSeries)),
                            grid: { display: false },
                        },
                    },
            },
        });
    }

    function renderStackedChart(canvasId, matrix) {
        destroyChart(canvasId);
        const element = document.getElementById(canvasId);
        if (!element) return;
        const colors = chartPalette((matrix.datasets || []).length || 1);
        charts[canvasId] = new Chart(element, {
            type: "bar",
            data: {
                labels: matrix.labels && matrix.labels.length ? matrix.labels : ["No data"],
                datasets: (matrix.datasets && matrix.datasets.length ? matrix.datasets : [{ label: "No data", data: [0] }]).map((dataset, index) => ({
                    ...dataset,
                    backgroundColor: colors[index % colors.length],
                    borderRadius: 8,
                    maxBarThickness: 36,
                })),
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label(context) {
                                return `${context.dataset.label}: ${context.parsed.y}`;
                            },
                        },
                    },
                },
                scales: {
                    x: { stacked: true, ticks: axisTickOptions((matrix.labels || []).length, false), grid: { display: false } },
                    y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } },
                },
            },
        });
    }

    function renderTrendChart(payload) {
        destroyChart("successTrendChart");
        const element = document.getElementById("successTrendChart");
        if (!element) return;
        charts.successTrendChart = new Chart(element, {
            type: "line",
            data: {
                labels: payload.labels && payload.labels.length ? payload.labels : ["No data"],
                datasets: (payload.datasets || []).map((dataset, index) => ({
                    ...dataset,
                    borderColor: index === 0 ? "#10b981" : "#ef4444",
                    backgroundColor: index === 0 ? "rgba(16,185,129,.14)" : "rgba(239,68,68,.14)",
                    fill: true,
                    tension: 0.28,
                })),
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: false,
                plugins: {
                    legend: { display: true },
                    tooltip: {
                        callbacks: {
                            label(context) {
                                return `${context.dataset.label}: ${context.parsed.y}`;
                            },
                        },
                    },
                },
                scales: {
                    y: { beginAtZero: true, ticks: { precision: 0 } },
                    x: { ticks: axisTickOptions((payload.labels || []).length, true), grid: { display: false } },
                },
            },
        });
    }

    function renderActivity(items) {
        const target = document.getElementById("analyticsActivityList");
        if (!target) return;
        if (!items || !items.length) {
            target.innerHTML = `
                <div class="empty-state compact-empty-state">
                    <i class="bi bi-journal-text"></i>
                    <div>
                        <div class="fw-semibold">No activity captured for this scope</div>
                        <div class="small text-secondary mb-0">Try widening the time range or removing filters to see more audit events.</div>
                    </div>
                </div>
            `;
            return;
        }
        target.innerHTML = items.map((item) => `
            <div class="timeline-item">
                <div class="d-flex justify-content-between gap-2">
                    <div class="fw-semibold">${(item.action || "Update").replaceAll("_", " ")}</div>
                    <span class="small text-secondary">${item.created_at || ""}</span>
                </div>
                <div class="small text-secondary">${item.username || "System"} | ${item.entity_type || "record"}${item.entity_id ? ` #${item.entity_id}` : ""}</div>
                <div class="small">${item.details || ""}</div>
            </div>
        `).join("");
    }

    function renderSimpleTable(bodyId, rows, columns, emptyMessage) {
        const body = document.getElementById(bodyId);
        if (!body) return;
        if (!rows || !rows.length) {
            body.innerHTML = emptyStateMarkup(emptyMessage, columns.length);
            return;
        }
        body.innerHTML = rows.map((row) => `
            <tr>
                ${columns.map((column) => {
                    const value = typeof column.render === "function" ? column.render(row) : (row[column.key] ?? "-");
                    return `<td>${value}</td>`;
                }).join("")}
            </tr>
        `).join("");
    }

    function mapFeatureCode(feature) {
        const properties = feature.properties || {};
        return properties.iso_a3 || properties.ISO_A3 || properties.adm0_a3 || properties.ADM0_A3 || feature.id;
    }

    function mapStyle(feature) {
        const key = mapFeatureCode(feature);
        const stats = mapStats[key] || { total: 0, prod: 0, status_counts: {} };
        const blockers = (stats.status_counts?.Failed || 0) + (stats.status_counts?.["Rolled Back"] || 0);
        const fillColor = blockers > 0
            ? "#ef4444"
            : stats.total > 0 && stats.prod < stats.total
                ? "#f59e0b"
                : stats.total > 0
                    ? "#10b981"
                    : "#dbe7f5";
        return {
            weight: key === currentParams().get("region") ? 2.2 : 1,
            opacity: 0.75,
            color: "#94a3b8",
            fillOpacity: stats.total > 0 ? 0.72 : 0.42,
            fillColor,
        };
    }

    function featureTooltip(feature) {
        const key = mapFeatureCode(feature);
        const stats = mapStats[key];
        if (!stats) {
            return `${feature.properties?.name || "Unknown"}<br>No matching changes`;
        }
        const blockers = (stats.status_counts?.Failed || 0) + (stats.status_counts?.["Rolled Back"] || 0);
        return `
            <div class="small fw-semibold">${feature.properties?.name || key}</div>
            <div class="small text-secondary">Total: ${stats.total}</div>
            <div class="small text-secondary">In PROD: ${stats.prod || 0}</div>
            <div class="small text-secondary">Blocked: ${blockers}</div>
        `;
    }

    function updateRegionFilter(regionCode) {
        const params = currentParams();
        if (regionCode) {
            params.set("region", regionCode);
        } else {
            params.delete("region");
        }
        window.location.href = `${window.location.pathname}${params.toString() ? `?${params.toString()}` : ""}`;
    }

    async function loadMap() {
        if (!document.getElementById("changesMap")) return;
        const params = currentParams().toString();
        const [statsResponse, geoResponse] = await Promise.all([
            fetch(`${config.mapUrl}?${params}`),
            fetch(config.worldGeoJsonUrl),
        ]);
        mapStats = await statsResponse.json();
        const geoJson = await geoResponse.json();

        if (!map) {
            map = L.map("changesMap", { zoomControl: true, minZoom: 1 }).setView([20, 0], 2);
            L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
                attribution: "&copy; OpenStreetMap contributors",
            }).addTo(map);
        }

        if (geoLayer) {
            geoLayer.remove();
        }

        geoLayer = L.geoJSON(geoJson, {
            style: mapStyle,
            onEachFeature(feature, layer) {
                layer.bindTooltip(featureTooltip(feature), { sticky: true });
                layer.on({
                    mouseover() {
                        layer.setStyle({ weight: 2.4, color: "#1d4ed8" });
                    },
                    mouseout() {
                        geoLayer.resetStyle(layer);
                    },
                    click() {
                        const code = mapFeatureCode(feature);
                        updateRegionFilter(code);
                    },
                });
            },
        }).addTo(map);
    }

    async function loadAnalytics() {
        setLoadingState(true);
        try {
            const response = await fetch(`${config.analyticsUrl}?${currentParams().toString()}`);
            const data = await response.json();

            setSummaryValue("total", data.summary?.total ?? 0);
            setSummaryValue("success", data.summary?.success ?? 0);
            setSummaryValue("failed", data.summary?.failed ?? 0);
            setSummaryValue("missing_prod", data.summary?.missing_prod ?? 0);
            setSummaryValue("stale", data.summary?.stale ?? 0);
            updateGroupingMeta(data.grouping || {});

            renderChart("volumeChart", "line", data.volume_chart?.labels, data.volume_chart?.data, "Changes", {
                borderColor: "#2563eb",
                backgroundColor: "rgba(37,99,235,.12)",
                fill: true,
                tension: 0.28,
                isTimeSeries: true,
            });
            renderChart("statusChart", "doughnut", data.status_chart?.labels, data.status_chart?.data, "Status");
            renderChart("envChart", "bar", data.env_chart?.labels, data.env_chart?.data, "Environment");
            renderChart("regionChart", "bar", data.region_chart?.labels, data.region_chart?.data, "Region");
            renderChart("systemChart", "bar", data.system_chart?.labels, data.system_chart?.data, "System");
            renderChart("deployerChart", "bar", data.deployer_chart?.labels, data.deployer_chart?.data, "Deployer");
            renderTrendChart(data.success_failure_trend || { labels: [], datasets: [] });
            renderStackedChart("matrixChart", data.matrix || { labels: [], datasets: [] });
            renderActivity(data.recent_activity || []);

            renderSimpleTable("devOnlyTableBody", data.dev_only || [], [
                { key: "jira_ref", render: (row) => `<a href="/change/${row.id}">${row.jira_ref}</a>` },
                { key: "title" },
                { key: "status", render: (row) => badgeMarkup(row.status) },
                { key: "deployed_by" },
                { key: "updated_at" },
            ], "No DEV-only / missing-PROD records match the current filters.");
            renderSimpleTable("staleTableBody", data.stale || [], [
                { key: "jira_ref", render: (row) => `<a href="/change/${row.id}">${row.jira_ref}</a>` },
                { key: "title" },
                { key: "status", render: (row) => badgeMarkup(row.status) },
                { key: "selected_environment" },
                { key: "updated_at" },
            ], "No stale changes found in the current scope.");
            renderSimpleTable("driftTableBody", data.drift || [], [
                { key: "jira_ref", render: (row) => `<a href="/change/${row.id}">${row.jira_ref}</a>` },
                { key: "title" },
                { key: "status", render: (row) => badgeMarkup(row.status) },
                { key: "selected_environment" },
                { key: "region" },
                { key: "updated_at" },
            ], "No drift records found for the current filters.");

            await loadMap();
        } catch (error) {
            console.error(error);
            ["total", "success", "failed", "missing_prod", "stale"].forEach((key) => setSummaryValue(key, "Unavailable"));
        } finally {
            setLoadingState(false);
        }
    }

    function setupInteractions() {
        const timeRange = document.getElementById("analyticsTimeRange");
        const customFields = document.querySelectorAll(".analytics-custom-range");
        if (timeRange) {
            timeRange.addEventListener("change", () => {
                const showCustom = timeRange.value === "custom";
                customFields.forEach((field) => field.classList.toggle("d-none", !showCustom));
            });
        }

        const clearMapSelectionBtn = document.getElementById("clearMapSelectionBtn");
        if (clearMapSelectionBtn) {
            clearMapSelectionBtn.addEventListener("click", () => updateRegionFilter(""));
        }

        const copyButton = document.getElementById("copyAnalyticsLinkBtn");
        if (copyButton) {
            copyButton.addEventListener("click", async () => {
                try {
                    await navigator.clipboard.writeText(window.location.href);
                    copyButton.textContent = "Link copied";
                    window.setTimeout(() => {
                        copyButton.innerHTML = '<i class="bi bi-link-45deg me-1"></i>Copy view link';
                    }, 1800);
                } catch (error) {
                    console.error(error);
                }
            });
        }
    }

    setupInteractions();
    loadAnalytics();
}());
