(function () {
    const config = window.appShellConfig || {};
    const storageKey = "jcl.sidebar.collapsed";
    const desktopBreakpoint = 992;
    const tabletBreakpoint = 1400;
    const body = document.body;
    const desktopSidebar = document.querySelector("[data-desktop-sidebar]");
    const collapseToggle = document.getElementById("sidebarCollapseToggle");
    const navLinks = Array.from(document.querySelectorAll("[data-nav-link]"));
    const tooltipInstances = navLinks.map((link) => new bootstrap.Tooltip(link, { trigger: "hover focus" }));

    function escapeHtml(value) {
        return String(value || "")
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#39;");
    }

    function setTooltipState(collapsed) {
        tooltipInstances.forEach((tooltip) => {
            if (collapsed) {
                tooltip.enable();
            } else {
                tooltip.hide();
                tooltip.disable();
            }
        });
    }

    function applySidebarState(collapsed, persist) {
        body.classList.toggle("sidebar-collapsed", collapsed);
        setTooltipState(collapsed);
        if (persist) {
            window.localStorage.setItem(storageKey, collapsed ? "1" : "0");
        }
    }

    function preferredSidebarState() {
        const stored = window.localStorage.getItem(storageKey);
        if (stored === "1" || stored === "0") {
            return stored === "1";
        }
        return window.innerWidth < tabletBreakpoint;
    }

    function syncSidebarForViewport() {
        if (!desktopSidebar) return;
        if (window.innerWidth < desktopBreakpoint) {
            body.classList.remove("sidebar-collapsed");
            setTooltipState(false);
            return;
        }
        applySidebarState(preferredSidebarState(), false);
    }

    if (collapseToggle) {
        collapseToggle.addEventListener("click", () => {
            const collapsed = !body.classList.contains("sidebar-collapsed");
            applySidebarState(collapsed, true);
        });
    }

    window.addEventListener("resize", syncSidebarForViewport);
    syncSidebarForViewport();

    document.addEventListener("keydown", (event) => {
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
            const searchInput = document.querySelector(".top-search input[name='q']");
            if (searchInput) {
                event.preventDefault();
                searchInput.focus();
                searchInput.select();
            }
        }
    });

    function wireRangeToggle(selectId, fieldSelector) {
        const select = document.getElementById(selectId);
        if (!select) return;
        const fields = document.querySelectorAll(fieldSelector);
        const sync = () => {
            const show = select.value === "custom";
            fields.forEach((field) => field.classList.toggle("d-none", !show));
        };
        select.addEventListener("change", sync);
        sync();
    }

    wireRangeToggle("analyticsTimeRange", ".analytics-custom-range");
    wireRangeToggle("releaseTimeRange", ".release-custom-range");

    const assistantDrawerElement = document.getElementById("assistantDrawer");
    const assistantForm = document.getElementById("assistantForm");
    const assistantPrompt = document.getElementById("assistantPrompt");
    const assistantResetBtn = document.getElementById("assistantResetBtn");
    const assistantResults = document.getElementById("assistantResults");
    const assistantInitialState = document.getElementById("assistantInitialState");
    const assistantLoadingState = document.getElementById("assistantLoadingState");
    const assistantSummaryText = document.getElementById("assistantSummaryText");
    const assistantChipBar = document.getElementById("assistantChipBar");
    const assistantCards = document.getElementById("assistantCards");
    const assistantLinks = document.getElementById("assistantLinks");
    const assistantGroundingNote = document.getElementById("assistantGroundingNote");
    const assistantDrawer = assistantDrawerElement ? bootstrap.Offcanvas.getOrCreateInstance(assistantDrawerElement) : null;

    function setAssistantState(state) {
        if (!assistantInitialState || !assistantLoadingState || !assistantResults) return;
        assistantInitialState.classList.toggle("d-none", state !== "initial");
        assistantLoadingState.classList.toggle("d-none", state !== "loading");
        assistantResults.classList.toggle("d-none", state !== "results");
    }

    function renderAssistantPayload(payload) {
        if (!assistantSummaryText || !assistantChipBar || !assistantCards || !assistantLinks || !assistantGroundingNote) return;

        assistantSummaryText.textContent = payload.summary || "No matching records found.";
        assistantGroundingNote.textContent = payload.grounding_note || "Results are grounded only in the current database records.";

        const chips = payload.chips || [];
        assistantChipBar.innerHTML = chips.length
            ? chips.map((chip) => `<span class="filter-chip"><strong>${escapeHtml(chip.label)}</strong>${escapeHtml(chip.value)}</span>`).join("")
            : '<span class="empty-inline py-0">No extra filters were inferred from this request.</span>';

        const links = payload.links || [];
        assistantLinks.innerHTML = links.length
            ? links.map((link) => `<a class="btn btn-sm btn-outline-primary" href="${escapeHtml(link.url)}">${escapeHtml(link.label)}</a>`).join("")
            : "";

        const cards = payload.cards || [];
        assistantCards.innerHTML = cards.length
            ? cards.map((card) => `
                <a class="assistant-card" href="${escapeHtml(card.url || "#")}">
                    <div class="assistant-card-title">${escapeHtml(card.title)}</div>
                    <div class="assistant-card-subtitle">${escapeHtml(card.subtitle)}</div>
                    <div class="assistant-card-meta">
                        ${(card.meta || []).filter(Boolean).map((item) => `<span class="badge-soft badge-soft-secondary">${escapeHtml(item)}</span>`).join("")}
                    </div>
                    <div class="assistant-card-detail">${escapeHtml(card.detail || "")}</div>
                </a>
            `).join("")
            : `
                <div class="empty-state compact-empty-state">
                    <i class="bi bi-search"></i>
                    <div>
                        <div class="fw-semibold">No matching records found</div>
                        <div class="small text-secondary mb-0">Try broadening the time range, removing one filter, or asking for a different system or region.</div>
                    </div>
                </div>
            `;

        setAssistantState("results");
    }

    async function runAssistantQuery(query) {
        if (!config.assistantUrl || !assistantPrompt) return;
        const prompt = (query || assistantPrompt.value || "").trim();
        if (!prompt) {
            setAssistantState("initial");
            return;
        }

        assistantPrompt.value = prompt;
        setAssistantState("loading");

        try {
            const response = await fetch(config.assistantUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ q: prompt }),
            });
            const payload = await response.json();
            renderAssistantPayload(payload);
        } catch (error) {
            console.error(error);
            renderAssistantPayload({
                summary: "The assistant could not load results right now.",
                cards: [],
                links: [],
                chips: [],
                grounding_note: "No assistant results were returned from the server.",
            });
        }
    }

    if (assistantForm) {
        assistantForm.addEventListener("submit", (event) => {
            event.preventDefault();
            runAssistantQuery();
        });
    }

    if (assistantResetBtn && assistantPrompt) {
        assistantResetBtn.addEventListener("click", () => {
            assistantPrompt.value = "";
            setAssistantState("initial");
        });
    }

    document.querySelectorAll(".assistant-suggestion").forEach((button) => {
        button.addEventListener("click", () => {
            const query = button.dataset.query || "";
            if (assistantDrawer) {
                assistantDrawer.show();
            }
            runAssistantQuery(query);
        });
    });

    if (config.initialAssistantQuery && assistantDrawer) {
        window.setTimeout(() => {
            assistantDrawer.show();
            runAssistantQuery(config.initialAssistantQuery);
        }, 220);
    }
}());
