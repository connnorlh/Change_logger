(function () {
    const dropZone = document.getElementById("jiraDropZone");
    const fileInput = dropZone ? dropZone.querySelector('input[type="file"]') : null;

    if (dropZone && fileInput) {
        ["dragenter", "dragover"].forEach((eventName) => dropZone.addEventListener(eventName, (event) => {
            event.preventDefault();
            dropZone.classList.add("is-dragging");
        }));
        ["dragleave", "drop"].forEach((eventName) => dropZone.addEventListener(eventName, (event) => {
            event.preventDefault();
            dropZone.classList.remove("is-dragging");
        }));
        dropZone.addEventListener("drop", (event) => {
            if (event.dataTransfer.files && event.dataTransfer.files.length) {
                fileInput.files = event.dataTransfer.files;
            }
        });
    }

    const toggleAllRows = document.getElementById("toggleAllRows");
    if (toggleAllRows) {
        toggleAllRows.addEventListener("click", () => {
            document.querySelectorAll(".include-row:not(:disabled)").forEach((checkbox) => {
                checkbox.checked = !checkbox.checked;
            });
        });
    }

    const applyBulkBtn = document.getElementById("applyBulkBtn");
    if (applyBulkBtn) {
        applyBulkBtn.addEventListener("click", () => {
            document.querySelectorAll(".bulk-control").forEach((control) => {
                const value = control.value;
                const target = control.dataset.target;
                if (!value || !target) return;
                document.querySelectorAll(".include-row:checked").forEach((checkbox) => {
                    const row = checkbox.closest("tr");
                    const field = row?.querySelector(`.row-bulk-target-${target}`);
                    if (field) field.value = value;
                });
            });
        });
    }

    const saveModeInput = document.getElementById("saveModeInput");
    if (saveModeInput) {
        document.querySelectorAll("[data-save-mode]").forEach((button) => {
            button.addEventListener("click", () => {
                saveModeInput.value = button.dataset.saveMode || "save_view";
            });
        });
    }

    const previewTargets = new Map();
    document.querySelectorAll("[data-preview-value]").forEach((node) => previewTargets.set(node.dataset.previewValue, node));
    function syncPreviewChips() {
        document.querySelectorAll(".live-preview-source").forEach((field) => {
            const target = field.dataset.previewTarget;
            const node = previewTargets.get(target);
            if (!node) return;
            node.textContent = field.value || "Not set";
        });
    }
    document.querySelectorAll(".live-preview-source").forEach((field) => {
        field.addEventListener("change", syncPreviewChips);
    });
    syncPreviewChips();

    const intakeTabs = document.getElementById("intakeTabs");
    if (intakeTabs) {
        const defaultTab = intakeTabs.dataset.defaultTab;
        const hash = window.location.hash;
        let selector = null;
        if (hash === "#manual-entry") selector = '[data-bs-target="#manual-entry-pane"]';
        if (hash === "#jira-import") selector = '[data-bs-target="#jira-import-pane"]';
        if (!selector && defaultTab === "manual") selector = '[data-bs-target="#manual-entry-pane"]';
        if (selector) {
            const trigger = intakeTabs.querySelector(selector);
            if (trigger) bootstrap.Tab.getOrCreateInstance(trigger).show();
        }
    }
}());
