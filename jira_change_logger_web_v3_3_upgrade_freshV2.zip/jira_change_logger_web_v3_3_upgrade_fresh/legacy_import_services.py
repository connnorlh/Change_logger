from __future__ import annotations

import html
import re
from datetime import date, datetime
from difflib import SequenceMatcher
from io import BytesIO
from typing import Any

from openpyxl import load_workbook
from openpyxl.utils.datetime import from_excel


ENV_DATE_FIELDS = {
    "DEV": "dev_date",
    "SIT": "sit_date",
    "UAT": "uat_date",
    "PREPROD": "preprod_date",
    "MIG": "mig_date",
    "PROD": "prod_date",
}

LEGACY_FIELD_ALIASES: dict[str, list[str]] = {
    "jira_ref": ["jira ref", "jira", "reference", "ticket", "change ref", "request id", "request", "issue key", "cr ref"],
    "title": ["title", "summary", "change title", "change summary", "short description"],
    "description": ["description", "details", "notes", "change details", "long description", "business description"],
    "selected_environment": ["environment", "env", "target environment", "deployment environment", "system env"],
    "system_name": ["system", "application", "platform", "service", "product", "system name"],
    "change_type": ["change type", "type", "category", "change category", "request type"],
    "status": ["status", "deployment status", "state", "implementation status"],
    "version": ["version", "release version", "build version", "fix version"],
    "region": ["region", "market", "country", "territory", "business region"],
    "deployed_by": ["deployed by", "owner", "implemented by", "implementer", "assigned to", "assignee"],
    "release_name": ["release", "release name", "release train", "wave", "release group"],
    "incident_ref": ["incident", "incident ref", "incident reference", "problem", "problem ref"],
    "notes": ["notes", "comments", "comment", "implementation notes", "support notes"],
    "old_value": ["old value", "before value", "previous value", "old configuration"],
    "new_value": ["new value", "after value", "updated value", "new configuration"],
    "deployment_date": ["deployment date", "date deployed", "implemented date", "go live date", "deployment", "date"],
    "dev_date": ["dev date", "dev deployed", "dev deployed date"],
    "sit_date": ["sit date", "sit deployed", "sit deployed date"],
    "uat_date": ["uat date", "uat deployed", "uat deployed date"],
    "preprod_date": ["preprod date", "pre prod date", "preproduction date"],
    "mig_date": ["mig date", "migration date", "migration deployed date"],
    "prod_date": ["prod date", "production date", "prod deployed date", "live date", "go live"],
    "created_at": ["created", "created at", "raised date", "request created", "logged date"],
    "updated_at": ["updated", "updated at", "modified", "last updated", "closed date"],
}

LEGACY_SHEET_OVERRIDES: dict[str, dict[str, str]] = {}

LEGACY_STATUS_ALIASES = {
    "planned": "Planned",
    "scheduled": "Planned",
    "pending": "Planned",
    "awaitingdeployment": "Planned",
    "approved": "Planned",
    "inprogress": "In Progress",
    "progress": "In Progress",
    "implementing": "In Progress",
    "deploymentinprogress": "In Progress",
    "readyforprod": "Ready for PROD",
    "readyforproduction": "Ready for PROD",
    "approvedforprod": "Ready for PROD",
    "deployed": "Deployed",
    "successful": "Deployed",
    "success": "Deployed",
    "complete": "Deployed",
    "completed": "Deployed",
    "implemented": "Deployed",
    "live": "Deployed",
    "failed": "Failed",
    "failure": "Failed",
    "error": "Failed",
    "rolledback": "Rolled Back",
    "rollback": "Rolled Back",
    "backedout": "Rolled Back",
}

LEGACY_ENVIRONMENT_ALIASES = {
    "dev": "DEV",
    "development": "DEV",
    "sit": "SIT",
    "systemintegrationtest": "SIT",
    "uat": "UAT",
    "useracceptancetest": "UAT",
    "preprod": "PREPROD",
    "preproduction": "PREPROD",
    "preprodution": "PREPROD",
    "mig": "MIG",
    "migration": "MIG",
    "prod": "PROD",
    "production": "PROD",
    "live": "PROD",
}

HELPER_SHEET_KEYWORDS = {
    "readme",
    "instruction",
    "instructions",
    "guide",
    "legend",
    "lookup",
    "template",
    "help",
    "summary",
}

JIRA_KEY_PATTERN = re.compile(r"\b([A-Z][A-Z0-9]+-\d+)\b")


class LegacyImportError(ValueError):
    pass


def normalize_header(value: str) -> str:
    return "".join(ch.lower() for ch in (value or "") if ch.isalnum())


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    text = html.unescape(str(value)).replace("\u00a0", " ")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.split("\n")]
    compacted: list[str] = []
    previous_blank = False
    for line in lines:
        if not line:
            if compacted and not previous_blank:
                compacted.append("")
            previous_blank = True
            continue
        compacted.append(line)
        previous_blank = False
    return "\n".join(compacted).strip()


def clean_inline_text(value: Any) -> str:
    return clean_text(value).replace("\n", " | ")


def extract_jira_ref(value: Any) -> tuple[str, str]:
    raw = clean_inline_text(value)
    if not raw:
        return "", ""
    match = JIRA_KEY_PATTERN.search(raw.upper())
    return (match.group(1) if match else "", raw)


def parse_excel_date(value: Any) -> tuple[str, str]:
    if value in (None, ""):
        return "", ""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d"), value.isoformat(sep=" ", timespec="minutes")
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d"), value.isoformat()
    if isinstance(value, (int, float)):
        try:
            parsed = from_excel(value)
            if isinstance(parsed, datetime):
                return parsed.strftime("%Y-%m-%d"), str(value)
            if isinstance(parsed, date):
                return parsed.strftime("%Y-%m-%d"), str(value)
        except Exception:
            pass
    raw = clean_inline_text(value)
    if not raw:
        return "", ""
    for candidate in (raw, raw.replace("Z", "+00:00")):
        try:
            parsed_dt = datetime.fromisoformat(candidate)
            return parsed_dt.strftime("%Y-%m-%d"), raw
        except ValueError:
            continue
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d %b %Y", "%d %B %Y"):
        try:
            parsed_dt = datetime.strptime(raw, fmt)
            return parsed_dt.strftime("%Y-%m-%d"), raw
        except ValueError:
            continue
    return "", raw


def normalize_option(value: Any, options: list[str], aliases: dict[str, str] | None = None) -> tuple[str, bool]:
    raw = clean_inline_text(value)
    if not raw:
        return "", True
    option_map = {normalize_header(item): item for item in options}
    raw_norm = normalize_header(raw)
    if raw_norm in option_map:
        return option_map[raw_norm], True
    if aliases:
        for alias, target in aliases.items():
            alias_norm = normalize_header(alias)
            if raw_norm == alias_norm or alias_norm in raw_norm:
                target_norm = normalize_header(target)
                return option_map.get(target_norm, target), True
    for option in options:
        option_norm = normalize_header(option)
        if option_norm and (option_norm in raw_norm or raw_norm in option_norm):
            return option, True
    best: tuple[float, str] | None = None
    for option in options:
        ratio = SequenceMatcher(None, raw_norm, normalize_header(option)).ratio()
        if ratio >= 0.82 and (best is None or ratio > best[0]):
            best = (ratio, option)
    if best:
        return best[1], True
    return raw, False


def normalize_region(value: Any, regions: list[dict[str, Any]]) -> tuple[str, str, bool]:
    raw = clean_inline_text(value)
    if not raw:
        return "", "", True
    lookup: dict[str, tuple[str, str]] = {}
    for region in regions:
        name = clean_inline_text(region.get("name", ""))
        iso3 = clean_inline_text(region.get("iso3", "")).upper()
        if name:
            lookup[normalize_header(name)] = (name, iso3)
        for alias in region.get("aliases", []):
            alias_name = clean_inline_text(alias)
            if alias_name:
                lookup[normalize_header(alias_name)] = (name or alias_name, iso3)
        if iso3:
            lookup[normalize_header(iso3)] = (name or iso3, iso3)
    raw_norm = normalize_header(raw)
    if raw_norm in lookup:
        return (*lookup[raw_norm], True)
    for key, value_tuple in lookup.items():
        if key and (key in raw_norm or raw_norm in key):
            return (*value_tuple, True)
    return raw, "", False


def unique_headers(values: list[Any]) -> list[str]:
    counts: dict[str, int] = {}
    headers: list[str] = []
    for idx, value in enumerate(values, start=1):
        header = clean_inline_text(value) or f"Column {idx}"
        counts[header] = counts.get(header, 0) + 1
        if counts[header] > 1:
            header = f"{header} ({counts[header]})"
        headers.append(header)
    return headers


def score_header_match(header: str, alias: str) -> float:
    header_norm = normalize_header(header)
    alias_norm = normalize_header(alias)
    if not header_norm or not alias_norm:
        return 0.0
    if header_norm == alias_norm:
        return 1.0
    if alias_norm in header_norm or header_norm in alias_norm:
        return 0.92
    header_tokens = set(re.findall(r"[a-z0-9]+", header.lower()))
    alias_tokens = set(re.findall(r"[a-z0-9]+", alias.lower()))
    if header_tokens and alias_tokens:
        overlap = len(header_tokens & alias_tokens) / max(len(alias_tokens), 1)
        if overlap >= 0.75:
            return 0.88 + (overlap * 0.05)
    return SequenceMatcher(None, header_norm, alias_norm).ratio()


def find_header_row(worksheet) -> tuple[int, list[str]] | tuple[None, None]:
    best_row_index: int | None = None
    best_headers: list[str] | None = None
    best_score = 0.0
    max_scan = min(worksheet.max_row or 0, 12)
    for row_index, row in enumerate(worksheet.iter_rows(min_row=1, max_row=max_scan, values_only=True), start=1):
        headers = unique_headers(list(row))
        non_empty = [header for header in headers if header and not header.startswith("Column ")]
        if len(non_empty) < 2:
            continue
        score = 0.0
        matched_headers = 0
        for header in headers:
            best_match = 0.0
            for aliases in LEGACY_FIELD_ALIASES.values():
                best_match = max(best_match, max(score_header_match(header, alias) for alias in aliases))
            if best_match >= 0.78:
                matched_headers += 1
                score += best_match
        score += matched_headers * 0.25
        if score > best_score:
            best_row_index = row_index
            best_headers = headers
            best_score = score
    if best_row_index is None or best_headers is None or best_score < 1.7:
        return None, None
    return best_row_index, best_headers


def map_sheet_columns(headers: list[str], sheet_name: str) -> tuple[dict[str, str], list[dict[str, str]]]:
    mapping: dict[str, str] = {}
    notes: list[dict[str, str]] = []
    sheet_override = LEGACY_SHEET_OVERRIDES.get(normalize_header(sheet_name), {})
    used_headers: set[str] = set()

    for field, override_header in sheet_override.items():
        if override_header in headers:
            mapping[field] = override_header
            used_headers.add(override_header)
            notes.append({"field": field, "header": override_header, "confidence": "override"})

    priority = [
        "jira_ref",
        "title",
        "description",
        "selected_environment",
        "system_name",
        "status",
        "deployment_date",
        "prod_date",
        "dev_date",
        "sit_date",
        "uat_date",
        "preprod_date",
        "mig_date",
        "region",
        "deployed_by",
        "change_type",
        "release_name",
        "version",
        "incident_ref",
        "notes",
        "old_value",
        "new_value",
        "created_at",
        "updated_at",
    ]

    for field in priority:
        if field in mapping:
            continue
        aliases = LEGACY_FIELD_ALIASES.get(field, [])
        best_header = ""
        best_score = 0.0
        for header in headers:
            if header in used_headers:
                continue
            score = max((score_header_match(header, alias) for alias in aliases), default=0.0)
            if score > best_score:
                best_score = score
                best_header = header
        if best_header and best_score >= 0.78:
            mapping[field] = best_header
            used_headers.add(best_header)
            confidence = "exact" if best_score >= 0.98 else "fuzzy"
            notes.append({"field": field, "header": best_header, "confidence": confidence})
    return mapping, notes


def infer_region_from_sheet(sheet_name: str, regions: list[dict[str, Any]]) -> tuple[str, str, bool]:
    return normalize_region(sheet_name, regions)


def derive_title(title: str, description: str, jira_ref: str) -> tuple[str, bool]:
    cleaned_title = clean_text(title)
    if cleaned_title:
        return cleaned_title, False
    description_text = clean_text(description)
    if description_text:
        first_line = description_text.split("\n", 1)[0].strip(" -:")
        return first_line[:120], True
    if jira_ref:
        return jira_ref, True
    return "", False


def compose_description(base_description: str, extras: dict[str, str]) -> str:
    blocks = [clean_text(base_description)] if clean_text(base_description) else []
    metadata_lines = []
    for label, value in extras.items():
        cleaned_value = clean_text(value)
        if cleaned_value:
            metadata_lines.append(f"- {label}: {cleaned_value}")
    if metadata_lines:
        blocks.append("Legacy import metadata:\n" + "\n".join(metadata_lines))
    return "\n\n".join(block for block in blocks if block).strip()


def payload_deployment_date(payload: dict[str, Any]) -> str:
    for field in ("prod_date", "mig_date", "preprod_date", "uat_date", "sit_date", "dev_date"):
        value = clean_inline_text(payload.get(field, ""))
        if value:
            return value
    return ""


def classify_row(blockers: list[str], warnings: list[str], duplicate: bool) -> tuple[str, str]:
    if duplicate:
        return "duplicate", "Duplicate"
    if blockers:
        status = "invalid" if len(blockers) >= 2 and any("No useful change data" in item for item in blockers) else "needs_review"
        return status, "Invalid" if status == "invalid" else "Needs review"
    if warnings:
        return "ready_warning", "Ready with warning"
    return "ready", "Ready"


def normalize_legacy_row(
    raw_values: dict[str, Any],
    mapping: dict[str, str],
    mapping_notes: list[dict[str, str]],
    sheet_name: str,
    row_number: int,
    context: dict[str, Any],
) -> dict[str, Any] | None:
    raw_display = {header: clean_inline_text(value) for header, value in raw_values.items() if clean_inline_text(value)}
    if not raw_display:
        return None

    warnings: list[str] = []
    blockers: list[str] = []
    sheet_mapping_warnings = [note for note in mapping_notes if note["confidence"] == "fuzzy" and note["field"] in {"jira_ref", "title", "description"}]
    if sheet_mapping_warnings:
        warnings.append("Critical columns were mapped heuristically for this sheet.")

    def field_value(name: str) -> Any:
        header = mapping.get(name, "")
        return raw_values.get(header) if header else None

    jira_ref, jira_ref_raw = extract_jira_ref(field_value("jira_ref"))
    if not jira_ref:
        for candidate_field in ("title", "description", "notes", "incident_ref"):
            jira_ref, _ = extract_jira_ref(field_value(candidate_field))
            if jira_ref:
                warnings.append("JIRA reference was inferred from free text.")
                break

    base_description = clean_text(field_value("description"))
    notes = clean_text(field_value("notes"))
    incident_ref = clean_inline_text(field_value("incident_ref"))
    title, title_derived = derive_title(clean_text(field_value("title")), base_description or notes, jira_ref)
    if title_derived and title:
        warnings.append("Title was derived because no dedicated title column was found.")

    supported_envs = context["settings"]["environments"]
    selected_environment, env_known = normalize_option(field_value("selected_environment"), supported_envs, LEGACY_ENVIRONMENT_ALIASES)
    if clean_inline_text(field_value("selected_environment")) and not env_known:
        warnings.append(f"Environment '{clean_inline_text(field_value('selected_environment'))}' was not recognised exactly.")

    supported_systems = context["settings"]["systems"]
    system_name, system_known = normalize_option(field_value("system_name"), supported_systems)
    if clean_inline_text(field_value("system_name")) and not system_known:
        warnings.append(f"System '{clean_inline_text(field_value('system_name'))}' was kept as imported text.")

    supported_statuses = context["settings"]["statuses"]
    status, status_known = normalize_option(field_value("status"), supported_statuses, LEGACY_STATUS_ALIASES)
    if clean_inline_text(field_value("status")) and not status_known:
        warnings.append(f"Status '{clean_inline_text(field_value('status'))}' was kept as imported text.")

    region_source = field_value("region")
    region_display, region_iso3, region_known = normalize_region(region_source, context["settings"]["regions"])
    if not region_display:
        region_display, region_iso3, region_known = infer_region_from_sheet(sheet_name, context["settings"]["regions"])
        if region_display and not region_known:
            warnings.append("Region was inferred from the worksheet name.")
    elif not region_known:
        warnings.append(f"Region '{clean_inline_text(region_source)}' was kept as imported text.")

    release_name = clean_inline_text(field_value("release_name"))
    release_id = context["release_lookup"].get(normalize_header(release_name))
    if release_name and not release_id:
        warnings.append(f"Release '{release_name}' was not matched to an existing release.")

    deployment_date, deployment_raw = parse_excel_date(field_value("deployment_date"))
    created_at, created_raw = parse_excel_date(field_value("created_at"))
    updated_at, updated_raw = parse_excel_date(field_value("updated_at"))

    payload = {
        "jira_ref": jira_ref,
        "title": title,
        "selected_environment": selected_environment,
        "system_name": system_name,
        "change_type": clean_inline_text(field_value("change_type")),
        "status": status,
        "version": clean_inline_text(field_value("version")),
        "region": region_display,
        "region_iso3": region_iso3,
        "deployed_by": clean_inline_text(field_value("deployed_by")) or context["username"],
        "description": "",
        "old_value": clean_text(field_value("old_value")),
        "new_value": clean_text(field_value("new_value")),
        "dev_date": "",
        "sit_date": "",
        "uat_date": "",
        "preprod_date": "",
        "mig_date": "",
        "prod_date": "",
        "release_id": release_id,
        "created_by": context["username"],
        "updated_by": context["username"],
        "created_at": created_at or context["timestamp"],
        "updated_at": updated_at or created_at or context["timestamp"],
    }

    for env_field, payload_field in ENV_DATE_FIELDS.items():
        env_value, env_raw = parse_excel_date(field_value(payload_field))
        if env_value:
            payload[payload_field] = env_value
        elif env_raw:
            warnings.append(f"{env_field} date '{env_raw}' could not be parsed.")

    if deployment_date:
        if selected_environment in ENV_DATE_FIELDS:
            payload[ENV_DATE_FIELDS[selected_environment]] = deployment_date
        else:
            warnings.append("A deployment date was found but no recognised environment was available to place it.")
    elif deployment_raw:
        warnings.append(f"Deployment date '{deployment_raw}' could not be parsed.")

    if clean_inline_text(field_value("created_at")) and not created_at:
        warnings.append(f"Created date '{created_raw}' could not be parsed, so the import timestamp will be used.")
    if clean_inline_text(field_value("updated_at")) and not updated_at:
        warnings.append(f"Updated date '{updated_raw}' could not be parsed, so the import timestamp will be used.")

    if not jira_ref:
        blockers.append("No JIRA reference could be extracted from this row.")
    if not title and not base_description and not notes:
        blockers.append("No useful change data was found for title or description.")

    metadata = {
        "Source sheet": sheet_name,
        "Source row": str(row_number),
        "Raw JIRA value": jira_ref_raw if jira_ref_raw and jira_ref_raw != jira_ref else "",
        "Incident ref": incident_ref,
        "Notes": notes,
        "Release": release_name if release_name and not release_id else "",
    }
    payload["description"] = compose_description(base_description, metadata)

    row = {
        "row_id": f"{normalize_header(sheet_name)}-{row_number}",
        "source_sheet": sheet_name,
        "source_row_number": row_number,
        "jira_ref_raw": jira_ref_raw,
        "mapping_notes": mapping_notes,
        "warnings": warnings,
        "blockers": blockers,
        "raw_values": raw_display,
        "change_payload": payload,
        "normalized": {
            "jira_ref": payload["jira_ref"],
            "title": payload["title"],
            "selected_environment": payload["selected_environment"],
            "system_name": payload["system_name"],
            "status": payload["status"],
            "region": payload["region"],
            "deployment_date": payload_deployment_date(payload),
            "release_name": release_name,
        },
        "duplicate_match": None,
        "duplicate_reason": "",
    }
    return row


def detect_duplicate(normalized_row: dict[str, Any], existing_rows: list[dict[str, Any]]) -> dict[str, Any] | None:
    payload = normalized_row["change_payload"]
    jira_ref = normalize_header(payload.get("jira_ref", ""))
    title = normalize_header(payload.get("title", ""))
    environment = normalize_header(payload.get("selected_environment", ""))
    region = normalize_header(payload.get("region", ""))
    deployment_date = normalize_header(payload_deployment_date(payload))

    for existing in existing_rows:
        if jira_ref and jira_ref == normalize_header(existing.get("jira_ref", "")):
            return {
                "id": existing.get("id"),
                "jira_ref": existing.get("jira_ref", ""),
                "title": existing.get("title", ""),
                "reason": "Matching JIRA reference already exists.",
            }

    for existing in existing_rows:
        existing_title = normalize_header(existing.get("title", ""))
        existing_env = normalize_header(existing.get("selected_environment", ""))
        existing_region = normalize_header(existing.get("region", ""))
        existing_date = normalize_header(existing.get("deployment_date", ""))
        if title and title == existing_title and environment and environment == existing_env:
            if region and existing_region and region != existing_region:
                continue
            if deployment_date and existing_date and deployment_date != existing_date:
                continue
            return {
                "id": existing.get("id"),
                "jira_ref": existing.get("jira_ref", ""),
                "title": existing.get("title", ""),
                "reason": "Title, environment, and deployment timing match an existing record.",
            }
    return None


def parse_legacy_workbook(file_bytes: bytes, file_name: str, context: dict[str, Any]) -> dict[str, Any]:
    if not file_bytes:
        raise LegacyImportError("The uploaded workbook is empty.")

    try:
        workbook = load_workbook(filename=BytesIO(file_bytes), data_only=True)
    except Exception as exc:
        raise LegacyImportError("The workbook could not be read. Please upload an .xlsx file with one sheet per market.") from exc

    preview_rows: list[dict[str, Any]] = []
    sheet_summaries: list[dict[str, Any]] = []
    relevant_sheet_count = 0

    for worksheet in workbook.worksheets:
        sheet_key = normalize_header(worksheet.title)
        if any(keyword in sheet_key for keyword in HELPER_SHEET_KEYWORDS):
            continue

        header_row_number, headers = find_header_row(worksheet)
        if not header_row_number or not headers:
            continue

        mapping, mapping_notes = map_sheet_columns(headers, worksheet.title)
        if not mapping:
            continue

        relevant_sheet_count += 1
        sheet_rows: list[dict[str, Any]] = []
        for row_number, row in enumerate(
            worksheet.iter_rows(min_row=header_row_number + 1, values_only=True),
            start=header_row_number + 1,
        ):
            row_values = {headers[idx]: row[idx] if idx < len(row) else None for idx in range(len(headers))}
            normalized_row = normalize_legacy_row(
                row_values,
                mapping,
                mapping_notes,
                worksheet.title,
                row_number,
                context,
            )
            if normalized_row is None:
                continue
            duplicate_match = detect_duplicate(normalized_row, context["existing_rows"])
            if duplicate_match:
                normalized_row["duplicate_match"] = duplicate_match
                normalized_row["duplicate_reason"] = duplicate_match["reason"]
            status_key, status_label = classify_row(
                normalized_row["blockers"],
                normalized_row["warnings"],
                bool(duplicate_match),
            )
            normalized_row["import_status"] = status_key
            normalized_row["import_status_label"] = status_label
            sheet_rows.append(normalized_row)

        if not sheet_rows:
            continue

        counts = {
            "ready": sum(1 for row in sheet_rows if row["import_status"] == "ready"),
            "ready_warning": sum(1 for row in sheet_rows if row["import_status"] == "ready_warning"),
            "duplicate": sum(1 for row in sheet_rows if row["import_status"] == "duplicate"),
            "needs_review": sum(1 for row in sheet_rows if row["import_status"] == "needs_review"),
            "invalid": sum(1 for row in sheet_rows if row["import_status"] == "invalid"),
        }
        sheet_summaries.append(
            {
                "sheet_name": worksheet.title,
                "header_row": header_row_number,
                "mapping": mapping,
                "mapping_notes": mapping_notes,
                "row_count": len(sheet_rows),
                **counts,
            }
        )
        preview_rows.extend(sheet_rows)

    if not preview_rows or relevant_sheet_count == 0:
        raise LegacyImportError("No importable worksheets were found. Check that the workbook has market tabs with header rows.")

    summary = {
        "sheet_count": len(sheet_summaries),
        "total_rows": len(preview_rows),
        "ready": sum(1 for row in preview_rows if row["import_status"] == "ready"),
        "ready_warning": sum(1 for row in preview_rows if row["import_status"] == "ready_warning"),
        "duplicate": sum(1 for row in preview_rows if row["import_status"] == "duplicate"),
        "needs_review": sum(1 for row in preview_rows if row["import_status"] == "needs_review"),
        "invalid": sum(1 for row in preview_rows if row["import_status"] == "invalid"),
    }

    return {
        "preview_type": "legacy_import",
        "file_name": file_name,
        "sheet_summaries": sheet_summaries,
        "rows": preview_rows,
        "summary": summary,
    }
